package br.gov.fazenda.receita.unidadesrfb.model;

import com.google.android.gms.maps.model.LatLng;
import com.google.maps.android.clustering.ClusterItem;

public class PlaceItem implements ClusterItem {

    private final LatLng position;
    private String title;
    private String snippet;
    private int type;
    private int size;

    @Override
    public String toString() {
        return "PlaceItem{" +
                "position=" + position +
                ", title='" + title + '\'' +
                ", snippet='" + snippet + '\'' +
                ", type=" + type +
                ", size=" + size +
                '}';
    }

    public PlaceItem(double lat, double lng) {
        this(lat, lng, null, null);
    }

    public PlaceItem(double lat, double lng, String title) {
        this(lat, lng, title, null);
    }

    public PlaceItem(double lat, double lng, String title, String snippet) {
        position = new LatLng(lat, lng);
        this.title = title;
        this.snippet = snippet;
    }

    public PlaceItem(LatLng position, String title, String snippet) {
        this.position = position;
        this.title = title;
        this.snippet = snippet;
    }

    @Override
    public LatLng getPosition() {
        return position;
    }

    @Override
    public String getTitle() {
        return title;
    }

    @Override
    public String getSnippet() {
        return snippet;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public void setSnippet(String snippet) {
        this.snippet = snippet;
    }

    public int getSize() {
        return size;
    }

    public void setSize(int size) {
        this.size = size;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }
}
