package br.gov.fazenda.receita.unidadesrfb.model.resultado;

import java.util.List;

import br.gov.fazenda.receita.rfb.model.RetornoPadrao;
import br.gov.fazenda.receita.unidadesrfb.model.SetorUA;

public class ResultadoConsultaUnidades extends RetornoPadrao {

    public List<SetorUA> listUnidades;
}
