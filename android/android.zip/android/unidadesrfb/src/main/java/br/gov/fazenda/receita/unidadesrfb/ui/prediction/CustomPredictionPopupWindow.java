package br.gov.fazenda.receita.unidadesrfb.ui.prediction;

import android.content.Context;
import android.view.ViewGroup;
import android.widget.FrameLayout;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.amsen.par.searchview.prediction.OnPredictionClickListener;
import com.amsen.par.searchview.prediction.Prediction;
import com.amsen.par.searchview.prediction.adapter.BasePredictionAdapter;
import com.amsen.par.searchview.prediction.adapter.DefaultPredictionAdapter;
import com.amsen.par.searchview.prediction.view.BasePredictionPopupWindow;

import java.util.List;

import br.gov.fazenda.receita.unidadesrfb.R;

public class CustomPredictionPopupWindow extends BasePredictionPopupWindow {
    private RecyclerView recycler;
    private FrameLayout emptyContainer;
    private BasePredictionAdapter adapter;
    private ViewGroup appBar;

    public CustomPredictionPopupWindow(Context context, ViewGroup appBar) {
        this(context, new DefaultPredictionAdapter(), appBar);
    }

    public CustomPredictionPopupWindow(Context context, BasePredictionAdapter<?> adapter, ViewGroup appBar) {
        super(context, R.layout.view_popup);

        this.adapter = adapter;
        this.appBar = appBar;
        recycler = getContentView().findViewById(R.id.recycler);
        emptyContainer = getContentView().findViewById(R.id.emptyContainer);
        recycler.setLayoutManager(new LinearLayoutManager(context, LinearLayoutManager.VERTICAL, false));
        recycler.setAdapter(adapter);
    }

    @Override
    public void applyPredictions(List<Prediction> predictions) {
        adapter.applyPredictions(predictions);
    }

    @Override
    public void setOnPredictionClickListener(OnPredictionClickListener listener) {
        adapter.setOnItemClickListener(listener);
    }

    @Override
    public void show() {
        showAsDropDown(appBar, 0, 0);
    }

    public RecyclerView getRecycler() {
        return recycler;
    }

    public BasePredictionAdapter getAdapter() {
        return adapter;
    }

    public void setAdapter(BasePredictionAdapter adapter) {
        this.adapter = adapter;
    }

    public FrameLayout getEmptyContainer() {
        return emptyContainer;
    }
}
