package br.gov.fazenda.receita.unidadesrfb.ui.prediction;

import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.amsen.par.searchview.prediction.OnPredictionClickListener;
import com.amsen.par.searchview.prediction.Prediction;
import com.amsen.par.searchview.prediction.adapter.PredictionHolder;

import br.gov.fazenda.receita.unidadesrfb.R;

public class CustomPredictionViewHolder extends PredictionHolder {
    private ViewGroup container;
    private TextView title;

    public CustomPredictionViewHolder(View itemView) {
        super(itemView);
        container = itemView.findViewById(R.id.container);
        title = itemView.findViewById(R.id.title);
    }

    @Override
    public void apply(int position, Prediction prediction, OnPredictionClickListener listener) {
        title.setText(prediction.displayString);
        container.setOnClickListener(e -> listener.onClick(position, prediction));
    }
}