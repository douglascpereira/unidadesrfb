package br.gov.fazenda.receita.unidadesrfb.ui.fragment;

import android.app.Activity;
import android.app.Dialog;
import android.content.DialogInterface;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.DialogFragment;

import br.gov.fazenda.receita.unidadesrfb.R;

public class MapFilterFragment extends DialogFragment {

    private Activity activity;
    private String[] items;
    private boolean[] checkedItems;
    private DialogInterface.OnMultiChoiceClickListener listener;

    public static int DELEGACIA = 0;
    public static int ALFANDEGA = 1;
    public static int INSPETORIA = 2;
    public static int CENTRO_ATENDIMENTO = 3;
    public static int POSTOS_ATENDIMENTO = 4;

    public MapFilterFragment(Activity activity, boolean[] checkedItems, DialogInterface.OnMultiChoiceClickListener listener) {
        this.activity = activity;
        this.items = new String[]{
                activity.getString(R.string.action_delegacias),
                activity.getString(R.string.action_alfandegas),
                activity.getString(R.string.action_inspetorias),
                activity.getString(R.string.action_centro_atendimento),
                activity.getString(R.string.action_postos_atendimento)
        };
        this.checkedItems = checkedItems;
        this.listener = listener;
    }

    @NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
        AlertDialog.Builder builder = new AlertDialog.Builder(activity);
        builder.setTitle(this.getString(R.string.menuitem_filtro));
        if (listener != null) {
            builder.setMultiChoiceItems(items, checkedItems, listener);
        }
        builder.setPositiveButton(this.getString(R.string.button_fechar), null);
        return builder.create();
    }

    public String[] getItems() {
        return items;
    }

    public void setItems(String[] items) {
        this.items = items;
    }

    public boolean[] getCheckedItems() {
        return checkedItems;
    }

    public void setCheckedItems(boolean[] checkedItems) {
        this.checkedItems = checkedItems;
    }
}
