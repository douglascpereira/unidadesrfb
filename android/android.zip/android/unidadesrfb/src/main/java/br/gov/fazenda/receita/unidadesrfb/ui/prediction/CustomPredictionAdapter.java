package br.gov.fazenda.receita.unidadesrfb.ui.prediction;

import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.annotation.NonNull;

import com.amsen.par.searchview.prediction.adapter.BasePredictionAdapter;

import br.gov.fazenda.receita.unidadesrfb.R;

public class CustomPredictionAdapter extends BasePredictionAdapter<CustomPredictionViewHolder> {

    @NonNull
    @Override
    public CustomPredictionViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        return new CustomPredictionViewHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.view_custom_prediction, parent, false));
    }
}