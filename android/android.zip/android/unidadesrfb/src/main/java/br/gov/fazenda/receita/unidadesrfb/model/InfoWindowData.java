package br.gov.fazenda.receita.unidadesrfb.model;

import java.util.List;

public class InfoWindowData {

    private String mSubTitle;
    private List<SetorUA> cluster;

    public String getSubTitle() {
        return mSubTitle;
    }

    public void setSubTitle(String mSubTitle) {
        this.mSubTitle = mSubTitle;
    }

    public List<SetorUA> getCluster() {
        return cluster;
    }

    public void setCluster(List<SetorUA> cluster) {
        this.cluster = cluster;
    }
}
