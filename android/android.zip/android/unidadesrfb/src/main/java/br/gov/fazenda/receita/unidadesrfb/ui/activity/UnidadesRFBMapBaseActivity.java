package br.gov.fazenda.receita.unidadesrfb.ui.activity;

import android.Manifest;
import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.text.Html;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;
import androidx.appcompat.widget.Toolbar;

import com.amsen.par.searchview.AutoCompleteSearchView;
import com.amsen.par.searchview.prediction.Prediction;
import com.amsen.par.searchview.util.ViewUtils;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.gson.Gson;
import com.google.maps.android.clustering.Cluster;
import com.google.maps.android.clustering.ClusterManager;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

import br.gov.fazenda.receita.rfb.util.CEP;
import br.gov.fazenda.receita.rfb.util.DataUtil;
import br.gov.fazenda.receita.rfb.util.PermissionUtil;
import br.gov.fazenda.receita.rfb.util.Strings;
import br.gov.fazenda.receita.rfb.util.Utils;
import br.gov.fazenda.receita.unidadesrfb.BuildConfig;
import br.gov.fazenda.receita.unidadesrfb.R;
import br.gov.fazenda.receita.unidadesrfb.model.InfoWindowData;
import br.gov.fazenda.receita.unidadesrfb.model.PlaceItem;
import br.gov.fazenda.receita.unidadesrfb.model.PlaceRenderer;
import br.gov.fazenda.receita.unidadesrfb.model.SetorUA;
import br.gov.fazenda.receita.unidadesrfb.ui.adapter.PopupAdapter;
import br.gov.fazenda.receita.unidadesrfb.ui.fragment.MapFilterFragment;
import br.gov.fazenda.receita.unidadesrfb.ui.prediction.CustomPredictionAdapter;
import br.gov.fazenda.receita.unidadesrfb.ui.prediction.CustomPredictionPopupWindow;
import br.gov.fazenda.receita.unidadesrfb.ui.task.ObterSetorUATask;
import br.gov.fazenda.receita.unidadesrfb.util.GpsUtils;

public abstract class UnidadesRFBMapBaseActivity extends AppCompatActivity implements OnMapReadyCallback,
        ClusterManager.OnClusterClickListener<PlaceItem>, SearchView.OnQueryTextListener,
        ClusterManager.OnClusterItemClickListener<PlaceItem>,
        ClusterManager.OnClusterItemInfoWindowClickListener<PlaceItem> {

    private static final String TAG = UnidadesRFBMapBaseActivity.class.getSimpleName();
    private static final String PROPERTY_CHECK_DATE_SETORUA = "check_date_setorua";

    protected Toolbar toolBar;
    protected Context context;
    private GoogleMap mMap;
    private PlaceRenderer mPlaceRenderer;
    private ClusterManager<PlaceItem> mClusterManager;
    private FusedLocationProviderClient mFusedLocationClient;
    private LocationRequest locationRequest;
    private LocationCallback locationCallback;
    private Location lastLocation = null;
    protected AutoCompleteSearchView mSearchView;

    protected boolean mCheckDelegacias = true;
    protected boolean mCheckAlfandegas = true;
    protected boolean mCheckInspetorias = true;
    protected boolean mCheckCentroAtendimento = true;
    protected boolean mCheckPostosAtendimento = true;

    private List<SetorUA> listSetorUA = Collections.emptyList();
    private List<SetorUA> listWithFilterSetorUA = new ArrayList<>();
    private BottomSheetDialog bottomSheetDialog;
    private boolean loadAutoComplete = true;
    private ArrayList<String> listAutoComplete = new ArrayList<>();
    private TimerTask networkCall;
    private Timer networkThread;
    private MenuItem searchViewItem;
    private boolean isGPS = false;

    public abstract void setContext();
    public abstract void openLink(String url);
    public abstract SharedPreferences getSharedPreferences();
    public abstract void setAnalytics(String screenName);

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        fixGoogleMapBug();
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_unidades_rfb_map);

        setContext();
        mFusedLocationClient = LocationServices.getFusedLocationProviderClient(context);

        locationRequest = LocationRequest.create();
        locationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
        locationRequest.setInterval(10 * 1000); // 10 seconds
        locationRequest.setFastestInterval(5 * 1000); // 5 seconds

        locationCallback = new LocationCallback() {
            @Override
            public void onLocationResult(LocationResult locationResult) {
                if (locationResult == null) {
                    return;
                }
                for (Location location : locationResult.getLocations()) {
                    if (location != null) {
                        lastLocation = location;
                        moveToAddress(location.getLatitude(), location.getLongitude());
                        mFusedLocationClient.removeLocationUpdates(locationCallback);
                    }
                }
            }
        };

        new GpsUtils(context).turnGPSOn(isGPSEnable -> {
            // turn on GPS
            isGPS = isGPSEnable;
        });

        networkThread = new Timer();
        setAnalytics("Mapa por Localização Atual");

        initToolBar();
        setUpMap();
    }

    @SuppressLint("MissingPermission")
    private void getLocation() {
        if (lastLocation == null && isGPS) {
            mFusedLocationClient.getLastLocation().addOnSuccessListener(location -> {
                Log.i(TAG, "location: " + location);
                if (location != null) {
                    lastLocation = location;
                    moveToAddress(location.getLatitude(), location.getLongitude());
                } else {
                    mFusedLocationClient.requestLocationUpdates(locationRequest, locationCallback, null);
                }
            });
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == Activity.RESULT_OK) {
            if (requestCode == GpsUtils.GPS_REQUEST) {
                isGPS = true;
                getLocation();
            }
        }
    }

    private void fixGoogleMapBug() {
        SharedPreferences googleBug = getSharedPreferences("google_bug", Context.MODE_PRIVATE);
        if (!googleBug.contains("fixed")) {
            File corruptedZoomTables = new File(getFilesDir(), "ZoomTables.data");
            corruptedZoomTables.delete();
            googleBug.edit().putBoolean("fixed", true).apply();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        setUpMap();
    }

    @SuppressLint("PrivateResource")
    protected void initToolBar() {
        toolBar = findViewById(R.id.myToolBar);
        setSupportActionBar(toolBar);
        toolBar.setNavigationIcon(R.drawable.abc_ic_ab_back_material);
        toolBar.setNavigationOnClickListener(v -> onBackPressed());
    }

    @TargetApi(Build.VERSION_CODES.M)
    private void checkPermissions() {
        List<String> permissionsList = new ArrayList<String>();
        for (String permission : getLocationPermissions()) {
            PermissionUtil.addPermission(this, permissionsList, permission);
        }

        if (permissionsList.size() > 0) {
            requestPermissions(permissionsList.toArray(new String[permissionsList.size()]), PermissionUtil.REQUEST_PERMISSIONS);
        } else {
            initMap();
        }
    }

    @TargetApi(Build.VERSION_CODES.M)
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == PermissionUtil.REQUEST_PERMISSIONS) {
            if (PermissionUtil.hasPermissions(this, getLocationPermissions())) {
                if (BuildConfig.DEBUG) Log.i(TAG, "Permission Granted.");
            } else {
                if (BuildConfig.DEBUG) Log.i(TAG, "Permission Denied.");
            }

            initMap();
        }
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        if (mMap != null) {
            return;
        }
        mMap = googleMap;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            checkPermissions();
        } else {
            initMap();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.action_menu_unidades_rfb, menu);

        searchViewItem = menu.findItem(R.id.menuitem_pesquisar);
        mSearchView = (AutoCompleteSearchView) searchViewItem.getActionView();
        mSearchView.setUseDefaultProgressBar(true);
        mSearchView.setUseDefaultPredictionPopupWindow(false);
        mSearchView.setPredictionPopupWindow(new CustomPredictionPopupWindow(context, new CustomPredictionAdapter(), ViewUtils.findActionBar((Activity) context)));
        mSearchView.setOnPredictionClickListener((position, prediction) -> {
            mSearchView.showProgressBar();
            setAnalytics("Consultar Mapa por Cidade");
            findAndMoveToAddress(prediction.displayString);
        });
        mSearchView.setOnQueryTextListener(this);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        super.onOptionsItemSelected(item);
        int itemId = item.getItemId();

        if (itemId == R.id.menuitem_filtro) {
            openDialogFragment();
            setAnalytics("Filtrar Mapa por Categoria");
        }
        return true;
    }

    private void openDialogFragment() {
        boolean[] checkedItems = new boolean[] {
                mCheckDelegacias,
                mCheckAlfandegas,
                mCheckInspetorias,
                mCheckCentroAtendimento,
                mCheckPostosAtendimento
        };

        DialogInterface.OnMultiChoiceClickListener listener = (dialog, which, isChecked) -> {
            if (which == MapFilterFragment.DELEGACIA) {
                mCheckDelegacias = isChecked;
                updateList();
            } else if (which == MapFilterFragment.ALFANDEGA) {
                mCheckAlfandegas = isChecked;
                updateList();
            } else if (which == MapFilterFragment.INSPETORIA) {
                mCheckInspetorias = isChecked;
                updateList();
            } else if (which == MapFilterFragment.CENTRO_ATENDIMENTO) {
                mCheckCentroAtendimento = isChecked;
                updateList();
            } else if (which == MapFilterFragment.POSTOS_ATENDIMENTO) {
                mCheckPostosAtendimento = isChecked;
                updateList();
            }
        };

        MapFilterFragment dialog = new MapFilterFragment(this, checkedItems, listener);
        dialog.show(getSupportFragmentManager(), "tag");
    }

    private void updateList() {
        listWithFilterSetorUA.clear();
        if (listSetorUA != null && listSetorUA.size() > 0) {
            for (SetorUA item : listSetorUA) {
                if (mCheckDelegacias && item.isDelegacia()) {
                    listWithFilterSetorUA.add(item);
                    continue;
                }
                if (mCheckAlfandegas && item.isAlfandega()) {
                    listWithFilterSetorUA.add(item);
                    continue;
                }
                if (mCheckInspetorias && item.isInspetoria()) {
                    listWithFilterSetorUA.add(item);
                    continue;
                }
                if (mCheckCentroAtendimento && item.isCentroDeAtendimento()) {
                    listWithFilterSetorUA.add(item);
                    continue;
                }
                if (mCheckPostosAtendimento && item.isAgenciaOuPostoDeAtendimento()) {
                    listWithFilterSetorUA.add(item);
                }
            }
        }
        addItens();
    }

    private void setUpMap() {
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map);
        if (mapFragment != null) {
            mapFragment.getMapAsync(this);
        }
    }

    @SuppressLint("MissingPermission")
    private void initMap() {
        mMap.getUiSettings().setZoomControlsEnabled(true);
        mMap.getUiSettings().setMapToolbarEnabled(false);
        mMap.setMyLocationEnabled(true);

        getLocation();

        mClusterManager = new ClusterManager<>(context, mMap);
        mPlaceRenderer = new PlaceRenderer(context, mMap, mClusterManager);
        mClusterManager.setRenderer(mPlaceRenderer);
        mClusterManager.setOnClusterClickListener(this);
        mClusterManager.setOnClusterItemClickListener(this);
        mClusterManager.setOnClusterItemInfoWindowClickListener(this);
        mMap.setOnMarkerClickListener(mClusterManager);
        mMap.setOnCameraIdleListener(mClusterManager);
        mMap.setOnInfoWindowClickListener(mClusterManager);

        carregarListaSetorUA();

        PopupAdapter mPopupAdapter = new PopupAdapter(LayoutInflater.from(context));
        mClusterManager.getMarkerCollection().setInfoWindowAdapter(mPopupAdapter);
        mMap.setInfoWindowAdapter(mClusterManager.getMarkerManager());
    }

    private void carregarListaSetorUA() {
        SharedPreferences prefs = getSharedPreferences();
        String prefs_date = prefs.getString(PROPERTY_CHECK_DATE_SETORUA, null);

        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd", DataUtil.LOC_PtBr);
        String today = null;
        try {
            today = sdf.format(new Date());
        } catch (Exception e) {
            e.printStackTrace();
        }

        File cacheFile = null;

        if (prefs_date == null || !prefs_date.equals(today)) {
            chamarServicoSetorUA();

            SharedPreferences.Editor editor = prefs.edit();
            editor.putString(PROPERTY_CHECK_DATE_SETORUA, today);
            editor.apply();
        } else {
            cacheFile = new File(getExternalCacheDir(), "setorUa.json");
            if (!cacheFile.exists()) {
                chamarServicoSetorUA();
            } else {
                try {
                    FileInputStream input = new FileInputStream(cacheFile);
                    BufferedReader bReader = new BufferedReader(new InputStreamReader(input));
                    String line = null;
                    StringBuilder json = new StringBuilder();
                    while ((line = bReader.readLine()) != null) {
                        if (!line.trim().equals("")) {
                            json.append(line);
                        }
                    }

                    SetorUA[] setorUA = new Gson().fromJson(json.toString(), SetorUA[].class);
                    if (setorUA != null) {
                        listSetorUA = Arrays.asList(setorUA);
                    }

                    bReader.close();
                    input.close();
                } catch (Exception e) {
                    if (BuildConfig.DEBUG) e.printStackTrace();
                }
                updateList();
            }
        }
    }

    private void addItens() {
        mClusterManager.clearItems();
        if (listWithFilterSetorUA.size() > 0) {
            for (SetorUA item : listWithFilterSetorUA) {
                if (item.latitudeEnd == null || item.longitudeEnd == null) {
                    continue;
                }
                LatLng latLng = new LatLng(Double.parseDouble(item.latitudeEnd), Double.parseDouble(item.longitudeEnd));
                PlaceItem placeItem = new PlaceItem(latLng, item.getNomeSetor(), getEndereco(item));
                placeItem.setSize(getClusterSize(item));
                placeItem.setType(getClusterType(item));
                mClusterManager.addItem(placeItem);
                loadAutoClomplete(item);
            }
            loadAutoComplete = false;
        }
        mClusterManager.cluster();
    }

    private int getClusterType(SetorUA item) {
        if (item.isDelegacia()) {
            return MapFilterFragment.DELEGACIA;
        } else if (item.isAlfandega()) {
            return MapFilterFragment.ALFANDEGA;
        } else if (item.isInspetoria()) {
            return MapFilterFragment.INSPETORIA;
        } else if (item.isAgenciaOuPostoDeAtendimento()) {
            return MapFilterFragment.POSTOS_ATENDIMENTO;
        } else if (item.isCentroDeAtendimento()) {
            return MapFilterFragment.CENTRO_ATENDIMENTO;
        }
        return -1;
    }

    private int getClusterSize(SetorUA item) {
        return getCluster(Double.parseDouble(item.latitudeEnd),
                Double.parseDouble(item.longitudeEnd)).size();
    }

    private List<SetorUA> getCluster(double latitude, double longitude) {
        List<SetorUA> cluster = new ArrayList<>();
        for (SetorUA item : listWithFilterSetorUA) {
            if (Double.parseDouble(item.latitudeEnd) == latitude
                    && Double.parseDouble(item.longitudeEnd) == longitude) {
                cluster.add(item);
            }
        }
        return cluster;
    }

    private void loadAutoClomplete(SetorUA item) {
        if (loadAutoComplete) {
            if (item.nomeMunicipio != null && item.siglaUf != null) {
                StringBuilder sb = new StringBuilder();
                sb.append(item.nomeMunicipio);
                sb.append(", ").append(item.siglaUf);
                addItemAutoComplete(sb.toString());
            }
        }
    }

    private String getEndereco(SetorUA item) {
        StringBuilder endereco = new StringBuilder();
        concatenarEndereco(endereco, item.logradouroEnd, "");
        concatenarEndereco(endereco, item.numeroEnd, ", ");
        concatenarEndereco(endereco, item.bairroEnd, " - ");
        concatenarEndereco(endereco, CEP.formatarCompleto(item.cepEnd), "<br>");
        concatenarEndereco(endereco, item.nomeMunicipio, ", ");
        concatenarEndereco(endereco, item.siglaUf, " - ");
        return Html.fromHtml(endereco.toString()).toString();
    }

    private void concatenarEndereco(StringBuilder endereco, String item, String separador) {
        if (Strings.isNotEmpty(item)) {
            if (endereco.length() > 0) {
                endereco.append(separador);
            }
            endereco.append(item);
        }
    }

    private void addItemAutoComplete(String newItem) {
        if (listAutoComplete.size() > 0) {
            boolean achou = false;
            for (String item : listAutoComplete) {
                if (item.equalsIgnoreCase(newItem)) {
                    achou = true;
                    break;
                }
            }
            if (!achou) {
                listAutoComplete.add(newItem);
            }
        } else {
            listAutoComplete.add(newItem);
        }
    }

    @SuppressLint("StaticFieldLeak")
    private void chamarServicoSetorUA() {
        ObterSetorUATask task = new ObterSetorUATask((Activity) context) {
            @Override
            protected void onPostExecute(List<SetorUA> setorUAS) {
                super.onPostExecute(setorUAS);
                listSetorUA = setorUAS;
                updateList();
            }
        };
        task.execute();
    }

    private Address getAddress(String palavraChave) {
        Geocoder geocoder = new Geocoder(context);
        List<Address> addresses;

        try {
            if (palavraChave != null) {
                addresses = geocoder.getFromLocationName(palavraChave, 10);
            } else {
                return null;
            }

            if (null != addresses && !addresses.isEmpty()) {
                if (BuildConfig.DEBUG) Log.d(TAG, "addresses: " + addresses.toString());
                return addresses.get(0);
            }
        } catch (IOException e) {
            if (BuildConfig.DEBUG) Log.e(TAG, e.getLocalizedMessage());
        }

        return null;
    }

    @Override
    public boolean onClusterClick(Cluster<PlaceItem> cluster) {
        try {
            mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(cluster.getPosition(),
                    (float) Math.floor(mMap.getCameraPosition().zoom + 3)), 300, null);
        } catch (Exception e) {
            if (BuildConfig.DEBUG) e.printStackTrace();
        }

        return true;
    }

    @Override
    public boolean onQueryTextSubmit(String query) {
        mSearchView.showProgressBar();
        if (isNumeric(query)) {
            setAnalytics("Consultar Mapa por CEP");
        } else {
            setAnalytics("Consultar Mapa por Cidade");
        }
        findAndMoveToAddress(query);
        return true;
    }

    public static boolean isNumeric(String strNum) {
        if (strNum == null) {
            return false;
        }
        strNum = strNum.replace("-", "");
        strNum = strNum.replace(" ", "");
        try {
            Double.parseDouble(strNum);
        } catch (NumberFormatException nfe) {
            return false;
        }
        return true;
    }

    @Override
    public boolean onQueryTextChange(String newText) {
        if (newText.length() > 0) {
            mSearchView.showProgressBar();
            loadPredctions(newText);
        }
        return true;
    }

    @Override
    public boolean onClusterItemClick(PlaceItem placeItem) {
        Marker marker = mPlaceRenderer.getMarker(placeItem);
        InfoWindowData info = new InfoWindowData();
        info.setCluster(getCluster(placeItem.getPosition().latitude, placeItem.getPosition().longitude));
        marker.setTag(info);
        return false;
    }

    @SuppressLint("InflateParams")
    @Override
    public void onClusterItemInfoWindowClick(PlaceItem placeItem) {
        View dialogView = getLayoutInflater().inflate(R.layout.bottom_sheet, null);
        LinearLayout agendarAtendimento = dialogView.findViewById(R.id.agendar_atendimento);
        agendarAtendimento.setOnClickListener(view -> openLink(
                "http://receita.economia.gov.br/interface/menu_atendimento/formas-de-atendimento"));

        LinearLayout maps = dialogView.findViewById(R.id.maps);
        maps.setOnClickListener(view -> verMaps(placeItem));

        LinearLayout directions = dialogView.findViewById(R.id.directions);
        directions.setOnClickListener(view -> calcularRotas(placeItem));

        TextView titulo = dialogView.findViewById(R.id.titulo);
        titulo.setText(placeItem.getTitle());

        InfoWindowData infoWindowData = (InfoWindowData) mPlaceRenderer.getMarker(placeItem).getTag();
        assert infoWindowData != null;
        LinearLayout outros = dialogView.findViewById(R.id.outros);
        if (infoWindowData.getCluster() != null && infoWindowData.getCluster().size() > 1) {
            outros.setVisibility(View.VISIBLE);
            outros.setOnClickListener(view -> listarUnidades(infoWindowData));
        } else {
            outros.setVisibility(View.GONE);
        }

        bottomSheetDialog = new BottomSheetDialog(context);
        bottomSheetDialog.setContentView(dialogView);
        bottomSheetDialog.show();
    }

    private void listarUnidades(InfoWindowData infoWindowData) {
        bottomSheetDialog.cancel();
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        final ArrayAdapter<SetorUA> arrayAdapter = new ArrayAdapter<>(context, R.layout.simple_list_item);
        arrayAdapter.addAll(infoWindowData.getCluster());
        builder.setTitle(getString(R.string.selecione_unidade));
        builder.setAdapter(arrayAdapter, (dialog, position) -> {
            clickMarker(infoWindowData, arrayAdapter.getItem(position));
            dialog.dismiss();
        });
        builder.create().show();
    }

    private void clickMarker(InfoWindowData infoWindowData, SetorUA setorUA) {
        if (setorUA != null) {
            for (Marker marker : mClusterManager.getMarkerCollection().getMarkers()) {
                LatLng latLng = new LatLng(Double.parseDouble(setorUA.latitudeEnd), Double.parseDouble(setorUA.longitudeEnd));
                if (marker.getPosition().equals(latLng) && marker.getTitle().equals(setorUA.getNomeSetor())) {
                    marker.setTag(infoWindowData);
                    marker.showInfoWindow();
                    break;
                }
            }
        }
    }

    private void calcularRotas(PlaceItem placeItem) {
        String origem = "";
        if (lastLocation != null) {
            origem = "&origin="+lastLocation.getLatitude()+","+lastLocation.getLongitude();
        }
        String destino = "&destination="+placeItem.getPosition().latitude+","+placeItem.getPosition().longitude;
        Uri intentUri = Uri.parse("https://www.google.com/maps/dir/?api=1&travelmode=driving"+origem+destino);
        chamarMaps(intentUri);
    }

    private void verMaps(PlaceItem placeItem) {
        Uri intentUri = Uri.parse("geo:0.0,0.0?q="+Uri.encode(placeItem.getSnippet()));
        chamarMaps(intentUri);
    }

    private void chamarMaps(Uri intentUri) {
        Intent mapIntent = new Intent(Intent.ACTION_VIEW, intentUri);
        mapIntent.setPackage("com.google.android.apps.maps");
        if (mapIntent.resolveActivity(getPackageManager()) != null) {
            startActivity(mapIntent);
        }
    }

    public static String[] getLocationPermissions() {
        return new String[]{
                Manifest.permission.ACCESS_COARSE_LOCATION,
                Manifest.permission.ACCESS_FINE_LOCATION
        };
    }

    private void findAndMoveToAddress(final String query) {
        if (networkCall != null) {
            networkCall.cancel();
            networkCall = null;
        }

        networkCall = new TimerTask() {
            @Override
            public void run() {
                if (BuildConfig.DEBUG) Log.d(TAG, "TextSubmit: " + query);
                Address endereco = getAddress(query);
                runOnUiThread(() -> {
                    networkCall = null;
                    if (endereco != null) {
                        moveToAddress(endereco.getLatitude(), endereco.getLongitude());
                    } else {
                        Toast.makeText(context, "Nenhum resultado encontrado.", Toast.LENGTH_SHORT).show();
                    }
                    mSearchView.hideProgressBar();
                    searchViewItem.collapseActionView();
                });
            }
        };

        networkThread.schedule(networkCall, 100);
    }

    private void moveToAddress(double latitude, double longitude) {
        LatLng currentLatLng = new LatLng(latitude, longitude);
        mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(currentLatLng, 12f));
        if (BuildConfig.DEBUG) Log.d(TAG, "Latitude: " + latitude + "  Longitude: " + longitude);
    }

    private void loadPredctions(final String query) {
        if (networkCall != null) {
            networkCall.cancel();
            networkCall = null;
        }

        networkCall = new TimerTask() {
            @Override
            public void run() {
                List<Prediction> predictions = toSearchViewPredictions(getPredictions(query));
                runOnUiThread(() -> {
                    networkCall = null;
                    if (predictions.size() > 0) {
                        mSearchView.applyPredictions(predictions);
                    }
                    mSearchView.hideProgressBar();
                });
            }
        };

        networkThread.schedule(networkCall, 100);
    }

    private List<Prediction> toSearchViewPredictions(List<String> predictions) {
        List<Prediction> forSearchView = new ArrayList<>();

        for (String prediction : predictions) {
            forSearchView.add(new Prediction(prediction, prediction));
        }

        return forSearchView;
    }

    protected List<String> getPredictions(String query) {
        List<String> mock = new ArrayList<>();

        if (query.length() > 0) {
            int amountOfResults = 8;

            for (String item : listAutoComplete) {
                String texto = Utils.removerAcentos(item);
                if (mock.size() <= amountOfResults) {
                    if (texto.contains(query.toUpperCase())) {
                        mock.add(item);
                    }
                }
            }
        }

        return mock;
    }


}