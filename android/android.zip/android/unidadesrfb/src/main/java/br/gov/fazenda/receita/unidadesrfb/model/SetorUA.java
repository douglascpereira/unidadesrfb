package br.gov.fazenda.receita.unidadesrfb.model;

import android.content.Context;
import android.util.Log;

import androidx.annotation.NonNull;

import com.google.gson.Gson;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Serializable;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import br.gov.fazenda.receita.rfb.exception.AmbienteIndisponivelException;
import br.gov.fazenda.receita.rfb.exception.ErroGenericoServidorException;
import br.gov.fazenda.receita.rfb.exception.ParametrosInformadosNaoInformadosException;
import br.gov.fazenda.receita.rfb.exception.UsuarioSemPermissaoDeAcessoException;
import br.gov.fazenda.receita.rfb.model.CodigoRetorno;
import br.gov.fazenda.receita.rfb.model.HeaderPadrao;
import br.gov.fazenda.receita.rfb.model.ParametroPadrao;
import br.gov.fazenda.receita.rfb.util.Constantes;
import br.gov.fazenda.receita.rfb.util.URLConnectionUtil;
import br.gov.fazenda.receita.unidadesrfb.BuildConfig;
import br.gov.fazenda.receita.unidadesrfb.model.resultado.ResultadoConsultaUnidades;

public class SetorUA implements Serializable {

    private static String TAG = SetorUA.class.getSimpleName();

    public int codigoSetor;
    private String nomeSetor;
    public String codigoUa;
    public String mnemonicoUa;
    public String codigoTipoSetor;
    public String siglaTipoSetor;
    public String codigoMunicipio;
    public String nomeMunicipio;
    public String siglaUf;
    public String logradouroEnd;
    public String complementoEnd;
    public String numeroEnd;
    public String bairroEnd;
    public String cepEnd;
    public String latitudeEnd;
    public String longitudeEnd;
    public String siglaTorg;

    @NonNull
    @Override
    public String toString() {
        return getNomeSetor();
    }

    public boolean isDelegacia() {
        return ((this.mnemonicoUa.equalsIgnoreCase("DECEX")
                || this.mnemonicoUa.equalsIgnoreCase("DEFIS")
                || this.mnemonicoUa.equalsIgnoreCase("DEINF")
                || this.mnemonicoUa.equalsIgnoreCase("DELEX")
                || this.mnemonicoUa.equalsIgnoreCase("DEMAC")
                || this.mnemonicoUa.equalsIgnoreCase("DERAT")
                || this.mnemonicoUa.equalsIgnoreCase("DERPF")
                || this.mnemonicoUa.equalsIgnoreCase("DRF")
                || this.mnemonicoUa.equalsIgnoreCase("DRJ"))
                && Integer.parseInt(this.codigoTipoSetor) == 72);
    }

    public boolean isAlfandega() {
        return (this.mnemonicoUa.equalsIgnoreCase("ALF")
                && Integer.parseInt(this.codigoTipoSetor) == 72);
    }

    public boolean isInspetoria() {
        return (this.mnemonicoUa.equalsIgnoreCase("IRF")
                && Integer.parseInt(this.codigoTipoSetor) == 72);
    }

    public boolean isCentroDeAtendimento() {
        return (Integer.parseInt(this.codigoTipoSetor) == 3);
    }

    public boolean isAgenciaOuPostoDeAtendimento() {
        return ((this.mnemonicoUa.equalsIgnoreCase("ARF")
                || this.mnemonicoUa.equalsIgnoreCase("POSTO"))
                && Integer.parseInt(this.codigoTipoSetor) == 72);
    }

    public static List<SetorUA> obterSetorUA(Context context) {
        ResultadoConsultaUnidades objRetorno = null;
        try {
            String url = BuildConfig.SERVICOS_RFB_URL + ":" + BuildConfig.SERVICOS_RFB_PORTA
                    + BuildConfig.SERVICOS_RFB_PATH + "IRPF/unidades/obter";

            HeaderPadrao headers = new HeaderPadrao(BuildConfig.NOME_APP, Constantes.VERSAO, Constantes.DISPOSITIVO, "1.0");

            objRetorno = URLConnectionUtil.doPost(url, headers, new ParametroPadrao(), ResultadoConsultaUnidades.class);

            if (objRetorno != null && objRetorno.listUnidades != null && objRetorno.listUnidades.size() > 0) {
                saveCache(context, new Gson().toJson(objRetorno.listUnidades));
            }

        } catch (Exception e) {
            e.printStackTrace();
            throw new AmbienteIndisponivelException();
        }

        if(objRetorno != null) {
            String retorno = objRetorno.codigoRetorno;
            String msgRetorno = objRetorno.mensagemRetorno;

            if (CodigoRetorno.OK.getValue().equals(retorno)) {
                return objRetorno.listUnidades;
            } else if (CodigoRetorno.ERRO_99.getValue().equals(retorno)) {
                throw new AmbienteIndisponivelException();
            } else if (CodigoRetorno.ERRO_01.getValue().equals(retorno)) {
                throw new ParametrosInformadosNaoInformadosException();
            } else if (CodigoRetorno.ERRO_02.getValue().equals(retorno)) {
                throw new UsuarioSemPermissaoDeAcessoException();
            } else if (CodigoRetorno.ERRO_03.getValue().equals(retorno)) {
                throw new ErroGenericoServidorException(msgRetorno);
            } else if (msgRetorno != null && !msgRetorno.contains("Sucesso")) {
                throw new ErroGenericoServidorException(msgRetorno);
            } else {
                throw new AmbienteIndisponivelException();
            }
        } else {
            throw new AmbienteIndisponivelException();
        }
    }

    public static List<SetorUA> mockObterSetorUA(Context context) {
        List<SetorUA> retorno = Collections.emptyList();
        try {
            InputStream input  = context.getAssets().open("setoruaREST.json");
            BufferedReader bReader = new BufferedReader(new InputStreamReader(input));
            String line = null;
            StringBuilder json = new StringBuilder();
            while ((line = bReader.readLine()) != null) {
                if (!line.trim().equals("")) {
                    json.append(line);
                }
            }

            saveCache(context, json.toString());

            SetorUA[] setorUA = new Gson().fromJson(json.toString(), SetorUA[].class);
            retorno = Arrays.asList(setorUA);

            bReader.close();
            input.close();

        } catch (Exception e) {
            if (BuildConfig.DEBUG) e.printStackTrace();
        }

        return retorno;
    }

    private static void saveCache(Context context, String json) throws IOException {
        File outputFile = new File(context.getExternalCacheDir(), "setorUa.json");
        if (!outputFile.exists()) {
            if (outputFile.createNewFile()) Log.e(TAG, "File Created");
        } else {
            if (outputFile.delete()) {
                Log.e(TAG, "File Deleted");
                if (outputFile.createNewFile()) Log.e(TAG, "File Created");
            }
        }

        FileOutputStream fos = new FileOutputStream(outputFile);
        fos.write(json.getBytes());
        fos.close();
    }

    public String getNomeSetor() {
        return nomeSetor.replace("GABIN - ", "");
    }

    public void setNomeSetor(String nomeSetor) {
        this.nomeSetor = nomeSetor;
    }
}
