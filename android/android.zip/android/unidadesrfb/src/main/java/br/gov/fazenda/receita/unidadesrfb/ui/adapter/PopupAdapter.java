package br.gov.fazenda.receita.unidadesrfb.ui.adapter;

import android.annotation.SuppressLint;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.model.Marker;

import java.util.List;

import br.gov.fazenda.receita.unidadesrfb.R;
import br.gov.fazenda.receita.unidadesrfb.model.InfoWindowData;
import br.gov.fazenda.receita.unidadesrfb.model.SetorUA;

public class PopupAdapter implements GoogleMap.InfoWindowAdapter {

    static class ViewHolder {
        TextView textViewTitle;
        TextView textViewSnippet;
        TextView textViewContador;
        Button buttonMaisOpcoes;
    }

    private View popup = null;
    private LayoutInflater inflater;

    public PopupAdapter(LayoutInflater inflater) {
        this.inflater = inflater;
    }

    @Override
    public View getInfoWindow(Marker marker) {
        return null;
    }

    @SuppressLint("InflateParams")
    @Override
    public View getInfoContents(Marker marker) {
        ViewHolder holder;
        if (popup == null) {
            popup = inflater.inflate(R.layout.popup, null);
            holder = new ViewHolder();
            holder.textViewTitle = popup.findViewById(R.id.title);
            holder.textViewSnippet = popup.findViewById(R.id.snippet);
            holder.textViewContador = popup.findViewById(R.id.contador);
            holder.buttonMaisOpcoes = popup.findViewById(R.id.button_mais_opcoes);
            popup.setTag(holder);
        } else {
            holder = (ViewHolder) popup.getTag();
        }
        holder.textViewTitle.setText(marker.getTitle());
        holder.textViewSnippet.setText(marker.getSnippet());

        InfoWindowData infoWindowData = (InfoWindowData) marker.getTag();
        assert infoWindowData != null;
        List<SetorUA> lista = infoWindowData.getCluster();
        if (lista != null && lista.size() > 1) {
            int posicao = 1;
            for (int i = 0; i < lista.size(); i++) {
                if (lista.get(i).getNomeSetor().equals(marker.getTitle())) {
                    posicao = i + 1;
                    break;
                }
            }
            StringBuilder sb = new StringBuilder();
            sb.append(posicao);
            sb.append("/");
            sb.append(lista.size());
            holder.textViewContador.setText(sb.toString());
            holder.textViewContador.setVisibility(View.VISIBLE);
        } else {
            holder.textViewContador.setVisibility(View.GONE);
        }

        return popup;
    }

}
