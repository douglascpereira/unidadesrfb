package br.gov.fazenda.receita.unidadesrfb.ui.task;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.ProgressDialog;
import android.os.AsyncTask;

import java.util.List;

import br.gov.fazenda.receita.rfb.exception.NoNetworkException;
import br.gov.fazenda.receita.rfb.util.HttpUtil;
import br.gov.fazenda.receita.unidadesrfb.R;
import br.gov.fazenda.receita.unidadesrfb.model.SetorUA;

public class ObterSetorUATask extends AsyncTask<Void, Void, List<SetorUA>> {

    public ProgressDialog dialog;
    @SuppressLint("StaticFieldLeak")
    public Activity activity;
    public Exception exception;

    public ObterSetorUATask(Activity activity) {
        this.activity = activity;
    }

    @Override
    protected void onPreExecute() {
        super.onPreExecute();
        this.dialog = ProgressDialog.show(activity, activity.getString(R.string.alertDialogTitle), activity.getString(R.string.alertDialogProcessando), true);
    }

    @Override
    protected void onPostExecute(List<SetorUA> setorUAS) {
        super.onPostExecute(setorUAS);
        if (this.dialog != null && this.dialog.isShowing())
            this.dialog.dismiss();
    }

    @Override
    protected List<SetorUA> doInBackground(Void... voids) {
        try {
            if (!HttpUtil.isOnline(activity)) {
                throw new NoNetworkException();
            }

            return SetorUA.obterSetorUA(activity);

        } catch (Exception e) {
            exception = e;
        }
        return null;
    }
}
