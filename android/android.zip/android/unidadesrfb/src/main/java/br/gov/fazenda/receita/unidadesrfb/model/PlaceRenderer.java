package br.gov.fazenda.receita.unidadesrfb.model;

import android.content.Context;

import androidx.annotation.NonNull;

import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.maps.android.clustering.Cluster;
import com.google.maps.android.clustering.ClusterManager;
import com.google.maps.android.clustering.view.DefaultClusterRenderer;

import br.gov.fazenda.receita.unidadesrfb.R;
import br.gov.fazenda.receita.unidadesrfb.ui.fragment.MapFilterFragment;

public class PlaceRenderer extends DefaultClusterRenderer<PlaceItem> implements GoogleMap.OnCameraMoveListener {

    private final GoogleMap mMap;
    private float currentZoom = 5f;
    private final float maxZoomLevel;

    public PlaceRenderer(Context context, GoogleMap map, ClusterManager<PlaceItem> clusterManager) {
        super(context, map, clusterManager);
        this.mMap = map;
        this.maxZoomLevel = map.getMaxZoomLevel() - 5f;
    }

    @Override
    protected void onBeforeClusterItemRendered(@NonNull PlaceItem item, @NonNull MarkerOptions markerOptions) {
        super.onBeforeClusterItemRendered(item, markerOptions);
        if (item.getSize() > 1) {
            markerOptions.icon(BitmapDescriptorFactory.fromResource(R.drawable.map_marker_multiple));
        } else if (item.getType() == MapFilterFragment.DELEGACIA){
            markerOptions.icon(BitmapDescriptorFactory.fromResource(R.drawable.map_marker));
        } else if (item.getType() == MapFilterFragment.INSPETORIA){
            markerOptions.icon(BitmapDescriptorFactory.fromResource(R.drawable.map_marker_magenta));
        } else if (item.getType() == MapFilterFragment.ALFANDEGA){
            markerOptions.icon(BitmapDescriptorFactory.fromResource(R.drawable.map_marker_vermelho));
        } else if (item.getType() == MapFilterFragment.CENTRO_ATENDIMENTO){
            markerOptions.icon(BitmapDescriptorFactory.fromResource(R.drawable.map_marker_verde_claro));
        } else if (item.getType() == MapFilterFragment.POSTOS_ATENDIMENTO){
            markerOptions.icon(BitmapDescriptorFactory.fromResource(R.drawable.map_marker_claro));
        }
    }

    @Override
    protected void onBeforeClusterRendered(@NonNull Cluster<PlaceItem> cluster, @NonNull MarkerOptions markerOptions) {
        super.onBeforeClusterRendered(cluster, markerOptions);
    }

    @Override
    protected boolean shouldRenderAsCluster(@NonNull Cluster<PlaceItem> cluster) {
        boolean wouldCluster = super.shouldRenderAsCluster(cluster);

        if (wouldCluster) {
            wouldCluster = currentZoom < maxZoomLevel;
        }

        return wouldCluster;
    }

    @Override
    public void onCameraMove() {
        currentZoom = mMap.getCameraPosition().zoom;
    }

}
