package com.amsen.par.searchview.prediction;

/**
 * @author Pär Amsen 2016
 */
public interface OnPredictionClickListener {
    void onClick(int position, Prediction prediction);
}
