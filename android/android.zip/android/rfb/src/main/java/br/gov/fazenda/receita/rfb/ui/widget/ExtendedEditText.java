package br.gov.fazenda.receita.rfb.ui.widget;

import android.content.Context;
import android.text.Editable;
import android.text.InputFilter;
import android.text.TextWatcher;
import android.util.AttributeSet;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import br.gov.fazenda.receita.rfb.R;

public class ExtendedEditText extends RelativeLayout {
	protected ImageView clearButton;
	protected EditText editText;
	protected int maxLength;
	protected View view;

	public ExtendedEditText(final Context context, final AttributeSet attributeSet) {
		super(context, attributeSet);
		view = inflate(context, R.layout.extended_edittext_layout, this);
	}

	public ExtendedEditText(final Context context) {
		super(context);
		view = inflate(context, R.layout.extended_edittext_layout, this);
	}

	protected void initialize(final Context context) {

		clearButton = (ImageView) view.findViewById(R.id.clearButton);
		editText = (EditText) view.findViewById(R.id.editText);
		
		InputFilter[] FilterArray = new InputFilter[1];
		FilterArray[0] = new InputFilter.LengthFilter(maxLength);
		editText.setFilters(FilterArray);
		
		clearButton.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				editText.setText("");
				clearButton.setVisibility(View.INVISIBLE);
			}

		});


		editText.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence s, int start, int before, int count) {

			}

			@Override
			public void beforeTextChanged(CharSequence s, int start, int count, int after) {
			}

			@Override
			public void afterTextChanged(Editable s) {
				if (editText.getText().length() == 1) {
					clearButton.setVisibility(View.VISIBLE);
				} else if (editText.getText().length() == 0) {
					clearButton.setVisibility(View.INVISIBLE);
				}
			}
		});

	}
	
	public EditText getEditText() {
		return editText;
	}
	
	public ImageView getClearButton() {
		return clearButton;
	}

}
