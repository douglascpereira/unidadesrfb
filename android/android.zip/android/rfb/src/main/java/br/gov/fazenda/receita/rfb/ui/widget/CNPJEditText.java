package br.gov.fazenda.receita.rfb.ui.widget;

import android.content.Context;
import android.util.AttributeSet;

public class CNPJEditText extends ExtendedEditText {

	public CNPJEditText(Context context) {
		super(context);
		maxLength = 14;
		initialize(context);
	}
	
	public CNPJEditText(final Context context, final AttributeSet attributeSet) {
		super(context, attributeSet);
		maxLength = 14;
		initialize(context);
	}
}
