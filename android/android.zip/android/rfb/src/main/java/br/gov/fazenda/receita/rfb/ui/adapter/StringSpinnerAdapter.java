package br.gov.fazenda.receita.rfb.ui.adapter;

import android.content.Context;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.SpinnerAdapter;
import android.widget.TextView;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import br.gov.fazenda.receita.rfb.R;

public class StringSpinnerAdapter extends ArrayAdapter<String> implements SpinnerAdapter {

	private Context context;
	private List<String> lista = Collections.emptyList();
	protected LayoutInflater inflater;

	static class ViewHolder {
		TextView text1;
		int position;
	}
	
	public StringSpinnerAdapter(Context context, String[] lista) {
		super(context, android.R.layout.simple_spinner_item);
		this.context = context;
		this.inflater = LayoutInflater.from(context);
		this.lista = Arrays.asList(lista);
	}
	
	public StringSpinnerAdapter(Context context, List<String> lista) {
		super(context, android.R.layout.simple_spinner_item);
		this.context = context;
		this.inflater = LayoutInflater.from(context);
		this.lista = lista;
	}
	
	@Override
	public int getCount() {
		return lista.size();
	}
	
	@Override
	public String getItem(int position) {
		return lista.get(position);
	}

	@Override
	public long getItemId(int position) {
		return position;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		ViewHolder holder;
		if (convertView == null) {
			convertView = inflater.inflate(android.R.layout.simple_spinner_item, null);
			holder = new ViewHolder();
			holder.text1 = convertView.findViewById(android.R.id.text1);
			holder.text1.setTextSize(TypedValue.COMPLEX_UNIT_SP, context.getResources().getDimension(R.dimen.font_extended_edittext));
			holder.position = position;
			convertView.setTag(holder);
		} else {
			holder = (ViewHolder) convertView.getTag();
		}

		String texto = lista.get(position);
		if (texto != null) {
			holder.text1.setText(texto);
		}
		
		return convertView;
	}

	@Override
	public View getDropDownView(int position, View convertView, ViewGroup parent) {
		ViewHolder holder;
		if (convertView == null) {
			convertView = inflater.inflate(android.R.layout.simple_list_item_1, null);
			holder = new ViewHolder();
			holder.text1 = convertView.findViewById(android.R.id.text1);
			holder.text1.setTextSize(TypedValue.COMPLEX_UNIT_SP, context.getResources().getDimension(R.dimen.font_extended_edittext));
			holder.position = position;
			convertView.setTag(holder);
		} else {
			holder = (ViewHolder) convertView.getTag();
		}

		String texto = lista.get(position);
		if (texto != null) {
			holder.text1.setText(texto);
		}
		
		return convertView;
	}
	
}
