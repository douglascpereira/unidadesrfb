package br.gov.fazenda.receita.rfb.ui.widget;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.NumberFormat;
import java.util.Locale;

import android.os.Build;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnFocusChangeListener;
import android.widget.EditText;

public class MoneyFormat implements TextWatcher {
	private String current = "";
	private EditText et;

	public MoneyFormat() {

	}

	public MoneyFormat(EditText et) {
		this.et = et;
		addListeners();
	}
	
	@Override
	public void onTextChanged(CharSequence s, int start, int before, int count) {
		if(et.getText().length() > 0) {
			if (!s.toString().equals(current)) {
				et.removeTextChangedListener(this);

				String cleanString = s.toString().replaceAll(isAndroidPie()?"[R$.,\\s]":"[R$.,]", "");
				
				if(cleanString.trim().contains(" "))
					cleanString = cleanString.substring(2)+cleanString.substring(0,1);

				BigDecimal parsed;
				String formated = "";
				try {
					parsed = new BigDecimal(cleanString.trim()).setScale(4, RoundingMode.DOWN);
					NumberFormat nf = NumberFormat.getCurrencyInstance(new Locale("pt", "BR"));
					formated = nf.format((parsed.doubleValue() / 100)).replaceAll(isAndroidPie()?"[R$\\s]":"[R$]", "");
				} catch (Exception e) {
					e.printStackTrace();
				}
		
				current = formated;
				et.setText(formated);
				et.setSelection(formated.length());
	
				et.addTextChangedListener(this);
			}
		} else {
			et.setText("0,00");
			et.setSelection(et.getText().length());
		}
	}
	
	@Override
	public void beforeTextChanged(CharSequence s, int start, int count,	int after) {

	}

	@Override
	public void afterTextChanged(Editable s) {
		
	}
	
	private void addListeners() {
		et.setOnFocusChangeListener(new OnFocusChangeListener() {
			
			@Override
			public void onFocusChange(View v, boolean hasFocus) {
				if (hasFocus)
					et.setSelection(et.getText().length());
			}
		});
		
		et.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				et.setSelection(et.getText().length());
			}
		});
	}

    private static boolean isAndroidPie() {
        return (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P);
    }
	
}
