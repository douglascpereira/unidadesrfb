package br.gov.fazenda.receita.rfb.util;

import android.os.Build;

import java.math.BigDecimal;
import java.text.NumberFormat;
import java.util.Currency;
import java.util.Locale;

public class MoedaUtil {

	public static final BigDecimal converterMoney(String valor){
		String cleanString = valor.trim().replaceAll(isAndroidPie()?"[R$.\\s]":"[R$. ]", "");
		cleanString = cleanString.trim().replace(",", ".");
		if(cleanString != null && !cleanString.equals(""))
			return new BigDecimal(cleanString);
		else
			return new BigDecimal(0.0);
	}

	public static final String converterMoney(double valor){
		NumberFormat nf = NumberFormat.getCurrencyInstance(new Locale("pt", "BR"));
		nf.setCurrency(Currency.getInstance("BRL"));
		return nf.format((valor)).replace(isAndroidPie()?"[R$\\s]":"R$", "R$ ");
	}	

	public static final String converterMoney(BigDecimal valor){
		NumberFormat nf = NumberFormat.getCurrencyInstance(new Locale("pt", "BR"));
		nf.setCurrency(Currency.getInstance("BRL"));
		return nf.format((valor)).replace(isAndroidPie()?"[R$\\s]":"R$", "R$ ");
	}

	public static final String converterMoneySemCifrao(BigDecimal valor){
		NumberFormat nf = NumberFormat.getCurrencyInstance(new Locale("pt", "BR"));
		nf.setCurrency(Currency.getInstance("BRL"));
		return nf.format((valor)).replace(isAndroidPie()?"[R$\\s]":"R$", "");
	}

	private static boolean isAndroidPie() {
		return (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P);
	}
}
