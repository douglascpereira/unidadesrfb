package br.gov.fazenda.receita.rfb.exception;

public class NenhumRegistroEncontradoException extends RuntimeException {

	private static final long serialVersionUID = 1L;

}
