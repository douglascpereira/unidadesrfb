package br.gov.fazenda.receita.rfb.util;

import android.app.Activity;
import android.content.Context;
import android.os.IBinder;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnKeyListener;
import android.view.inputmethod.InputMethodManager;

public class KeyboardUtils {

	public static void esconderTeclado(Activity activity, IBinder binder) {
		InputMethodManager imm = (InputMethodManager) activity.getSystemService(Context.INPUT_METHOD_SERVICE);
		imm.hideSoftInputFromWindow(binder, 0);
	}
	
	public static class ConcreteKeyListener implements OnKeyListener {
		private View view;
		private Activity activity;
		public ConcreteKeyListener() {
			super();
		}
		
		public ConcreteKeyListener(View v) {
			super();
			this.view = v;
		}
		
		public ConcreteKeyListener(Activity activity, View v) {
			super();
			this.view = v;
			this.activity = activity;
		}		
		
		@Override
		public boolean onKey(View v, int keyCode, KeyEvent event) {
			
			if (event.getAction() == KeyEvent.ACTION_DOWN)
	        {
	            switch (keyCode)
	            {
	                case KeyEvent.KEYCODE_ENTER:
	                	if(v.getTag() != null && v.getTag().toString().equalsIgnoreCase("ultimoCampo")) {
	                		KeyboardUtils.esconderTeclado(activity, v.getWindowToken());
               				this.view.clearFocus();
	                	} else {
	                		this.view.requestFocus();
	                	}
	                    return true;
	                default:
	                    break;
	            }
	        }
	        return false;	
		}
	}

	public static void mostrarTeclado(Activity activity, View binder) {
		InputMethodManager imm = (InputMethodManager) activity.getSystemService(Context.INPUT_METHOD_SERVICE);
		imm.showSoftInput(binder, InputMethodManager.SHOW_FORCED);
	}
}
