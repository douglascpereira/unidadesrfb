package br.gov.fazenda.receita.rfb.util;

import android.util.Log;

import com.google.gson.Gson;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.lang.reflect.Field;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.NoSuchAlgorithmException;

import javax.net.ssl.HttpsURLConnection;

import br.gov.fazenda.receita.rfb.BuildConfig;
import br.gov.fazenda.receita.rfb.model.HeaderPadrao;
import br.gov.fazenda.receita.rfb.model.RetornoPadrao;

public class URLConnectionUtil {

    private static final String TAG = URLConnectionUtil.class.getSimpleName();

    private static HttpURLConnection getURLConnection(URL url) throws IOException {

        if (url.getProtocol().equalsIgnoreCase("https")) {
            return (HttpsURLConnection) url.openConnection();
        } else {
            return (HttpURLConnection) url.openConnection();
        }
    }

    public static <T extends RetornoPadrao> T doPost(String strURL, HeaderPadrao headers, Object json, Class<T> clazz) throws NoSuchAlgorithmException, IOException, IllegalAccessException, InstantiationException {
        return doConnect("POST", strURL, headers, json, clazz);
    }

    public static <T extends RetornoPadrao> T doGet(String strURL, HeaderPadrao headers, Object json, Class<T> clazz) throws NoSuchAlgorithmException, IOException, IllegalAccessException, InstantiationException {
        return doConnect("GET", strURL, headers, json, clazz);
    }

    public static String doPost(String strURL, HeaderPadrao headers, Object json) throws NoSuchAlgorithmException, IOException, IllegalAccessException {
        return doConnect("POST", strURL, headers, json);
    }

    public static String doGet(String strURL, HeaderPadrao headers, Object json) throws NoSuchAlgorithmException, IOException, IllegalAccessException {
        return doConnect("GET", strURL, headers, json);
    }

    public static <T extends RetornoPadrao> T doConnect(String method, String strURL, HeaderPadrao headers, Object json, Class<T> clazz) throws NoSuchAlgorithmException, IOException, IllegalAccessException, InstantiationException {
        StringBuffer response;
        int responseCode;
        String message;

        URL url = new URL(strURL);
        HttpURLConnection con = getURLConnection(url);

        if (BuildConfig.DEBUG) {
            Log.i(TAG, "URL: " + strURL);
            Log.i(TAG, "Headers: " + headers.toString());
        }

        con.setRequestMethod(method);
        if (headers.aplicativo != null)
            con.setRequestProperty("aplicativo", headers.aplicativo);
        if (headers.dispositivo != null)
            con.setRequestProperty("dispositivo", headers.dispositivo);
        if (headers.versaoSO != null)
            con.setRequestProperty("versao", headers.versaoSO);
        if (headers.versaoAPP != null)
            con.setRequestProperty("versao_app", headers.versaoAPP);
        if (headers.token != null)
            con.setRequestProperty("token", headers.token);
        if (headers.so != null)
            con.setRequestProperty("plataforma", headers.so);
        if (headers.rest != null)
            con.setRequestProperty("rest", headers.rest);
        if (headers.contentType != null)
            con.setRequestProperty("Content-Type", headers.contentType);
        if (headers.userAgent != null)
            con.setRequestProperty("User-Agent", headers.userAgent);
        if (headers.acceptEncoding != null)
            con.setRequestProperty("Accept-Encoding", headers.acceptEncoding);
        if (headers.acceptCharset != null)
            con.setRequestProperty("Accept-Charset", headers.acceptCharset);

        Gson gson = new Gson();
        if (headers.contentType != null) {
            OutputStream os = con.getOutputStream();
            if (headers.contentType.equals("application/json")) {
                String jsonParam = gson.toJson(json);

                if (BuildConfig.DEBUG) {
                    Log.i(TAG, "Parameters: " + jsonParam);
                }

                os.write(jsonParam.getBytes());
                os.flush();
            } else {
                StringBuilder postData = new StringBuilder();
                for (Field item : json.getClass().getDeclaredFields()) {
                    if (item.get(json) != null) {
                        if (postData.length() != 0) postData.append('&');
                        postData.append(item.getName());
                        postData.append('=');
                        postData.append(String.valueOf(item.get(json)));
                    }
                }

                if (BuildConfig.DEBUG) {
                    Log.i(TAG, "Parameters: " + postData.toString());
                }

                os.write(postData.toString().getBytes());
                os.flush();
            }
        }

        responseCode = con.getResponseCode();
        message = con.getResponseMessage();
        InputStream isError = con.getErrorStream();
        if(isError != null) {
            BufferedReader in = new BufferedReader(new InputStreamReader(con.getErrorStream()));
            String inputLine;
            StringBuffer errors = new StringBuffer();
            while ((inputLine = in.readLine()) != null) {
                errors.append(inputLine);
            }
        }

        BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
        response = new StringBuffer();
        String inputLine;
        while ((inputLine = in.readLine()) != null) {
            response.append(inputLine);
        }
        in.close();
        con.disconnect();

        if (BuildConfig.DEBUG) {
            Log.i(TAG, "Response Code: " + responseCode);
            Log.i(TAG, "Message: " + message);
            Log.i(TAG, "Response: " + response);
        }

        return (responseCode == 200) ? (T) gson.fromJson(response.toString(), clazz.newInstance().getClass()) : null;
    }

    private static String doConnect(String method, String strURL, HeaderPadrao headers, Object json) throws NoSuchAlgorithmException, IOException, IllegalAccessException {
        StringBuffer response;
        int responseCode;
        String message;

        URL url = new URL(strURL);
        HttpURLConnection con = getURLConnection(url);

        if (BuildConfig.DEBUG) {
            Log.i(TAG, "URL: " + strURL);
            Log.i(TAG, "Headers: " + headers.toString());
        }

        con.setRequestMethod(method);
        if (headers.aplicativo != null)
            con.setRequestProperty("aplicativo", headers.aplicativo);
        if (headers.dispositivo != null)
            con.setRequestProperty("dispositivo", headers.dispositivo);
        if (headers.versaoSO != null)
            con.setRequestProperty("versao", headers.versaoSO);
        if (headers.versaoAPP != null)
            con.setRequestProperty("versao_app", headers.versaoAPP);
        if (headers.token != null)
            con.setRequestProperty("token", headers.token);
        if (headers.so != null)
            con.setRequestProperty("so", headers.so);
        if (headers.rest != null)
            con.setRequestProperty("rest", headers.rest);
        if (headers.contentType != null)
            con.setRequestProperty("Content-Type", headers.contentType);
        if (headers.userAgent != null)
            con.setRequestProperty("User-Agent", headers.userAgent);
        if (headers.acceptEncoding != null)
            con.setRequestProperty("Accept-Encoding", headers.acceptEncoding);
        if (headers.acceptCharset != null)
            con.setRequestProperty("Accept-Charset", headers.acceptCharset);

        if (headers.contentType != null) {
            OutputStream os = con.getOutputStream();
            if (headers.contentType.equals("application/json")) {
                Gson gson = new Gson();
                String jsonParam = gson.toJson(json);

                if (BuildConfig.DEBUG) {
                    Log.i(TAG, "Parameters: " + jsonParam);
                }

                os.write(jsonParam.getBytes());
                os.flush();
            } else {
                StringBuilder postData = new StringBuilder();
                for (Field item : json.getClass().getDeclaredFields()) {
                    if (postData.length() != 0) postData.append('&');
                    postData.append(item.getName());
                    postData.append('=');
                    postData.append(String.valueOf(item.get(json)));
                }

                if (BuildConfig.DEBUG) {
                    Log.i(TAG, "Parameters: " + postData.toString());
                }

                os.write(postData.toString().getBytes());
                os.flush();
            }
        }

        responseCode = con.getResponseCode();
        message = con.getResponseMessage();

        BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
        String inputLine;
        response = new StringBuffer();
        while ((inputLine = in.readLine()) != null) {
            response.append(inputLine);
        }
        in.close();
        con.disconnect();

        if (BuildConfig.DEBUG) {
            Log.i(TAG, "Response Code: " + responseCode);
            Log.i(TAG, "Message: " + message);
            Log.i(TAG, "Response: " + response);
        }

        return (responseCode == 200) ? response.toString() : null;
    }
}