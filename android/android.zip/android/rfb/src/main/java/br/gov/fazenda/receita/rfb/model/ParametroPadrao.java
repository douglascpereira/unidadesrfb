package br.gov.fazenda.receita.rfb.model;

import java.io.Serializable;

public class ParametroPadrao implements Serializable {

    private static final long serialVersionUID = 1L;

    public String url;
    public String tokenAuth;
}
