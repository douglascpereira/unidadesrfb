package br.gov.fazenda.receita.rfb.ui.widget;

import android.content.Context;
import android.util.AttributeSet;

import androidx.appcompat.widget.AppCompatEditText;

public class NoImeEditText extends AppCompatEditText {
	
	public NoImeEditText(Context context, AttributeSet attrs) {
		super(context, attrs);
	}

	@Override
	public boolean onCheckIsTextEditor() {
		return false;
	}
}
