package br.gov.fazenda.receita.rfb.util;

import android.view.View;
import android.view.View.MeasureSpec;
import android.view.ViewGroup;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.RelativeLayout;

public final class WidgetUtil {

	public static void calcularAlturaListView(ListView listView) {
		ListAdapter listAdapter = listView.getAdapter();
		if (listAdapter == null) {
			return;
		}

		int totalAltura = 0;

		for (int i = 0; i < listAdapter.getCount(); i++) {
			View listItem = listAdapter.getView(i, null, listView);
			listItem.setLayoutParams(new RelativeLayout.LayoutParams(RelativeLayout.LayoutParams.WRAP_CONTENT,
					RelativeLayout.LayoutParams.WRAP_CONTENT));

			listItem.measure(MeasureSpec.UNSPECIFIED, MeasureSpec.UNSPECIFIED);
			totalAltura += listItem.getMeasuredHeight() + listView.getDividerHeight();
		}

		listView.getLayoutParams().height = totalAltura;
	}

	public static void disabledViews(ViewGroup vg) {
		for (int i = 0; i < vg.getChildCount(); i++) {
			View child = vg.getChildAt(i);
			child.setEnabled(false);
			if (child instanceof ViewGroup) {
				disabledViews((ViewGroup) child);
			}
		}
	}
}
