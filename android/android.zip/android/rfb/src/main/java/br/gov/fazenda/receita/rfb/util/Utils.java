package br.gov.fazenda.receita.rfb.util;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.os.Build;
import android.text.Spanned;

import java.lang.reflect.Field;
import java.text.Normalizer;
import java.util.Locale;
import java.util.Set;

import br.gov.fazenda.receita.rfb.R;

public class Utils {

	public static void mensagemDeAlerta(String titulo, String alertDialogButtonPositive, Activity activity, String mensagem) {
		mensagemDeAlerta(titulo, alertDialogButtonPositive, (Context) activity, mensagem);
	}

	public static void mensagemDeAlerta(String titulo, String alertDialogButtonPositive, Activity activity, Spanned mensagem) {
		mensagemDeAlerta(titulo, alertDialogButtonPositive, (Context) activity, mensagem.toString());
	}

	public static void mensagemDeAlerta(String titulo, String alertDialogButtonPositive, Context context, Spanned mensagem) {
		mensagemDeAlerta(titulo, alertDialogButtonPositive, context, mensagem.toString());
	}

	public static void mensagemDeAlerta(String titulo, String alertDialogButtonPositive, Context context, String mensagem) {
		AlertDialog.Builder builder = new AlertDialog.Builder(context);
		builder.setTitle(titulo).setPositiveButton(alertDialogButtonPositive, null);
		builder.setMessage(mensagem);
		builder.create().show();
	}

	@Deprecated
	public static void setLinguagemPadrao(Context context) {
		Configuration config = context.getResources().getConfiguration();
		Locale locale = new Locale("pt", "BR");
		Locale.setDefault(locale);
		config.locale = locale;
		context.getResources().updateConfiguration(config, context.getResources().getDisplayMetrics());
	}
    public static String unmask(String s, Set<String> replaceSymbols) {

        for (String symbol : replaceSymbols)
            s = s.replaceAll("["+symbol+"]","");

        return s;
    }

    public static String unmask(String s) {

        s = s.replace("(", "");
        s = s.replace(")","");
        s = s.replace("-","");

        return s;
    }

    public static String mask(String format, String text){
        String maskedText="";
        int i =0;
        for (char m : format.toCharArray()) {
            if (m != '#') {
                maskedText += m;
                continue;
            }
            try {
                maskedText += text.charAt(i);
            } catch (Exception e) {
                break;
            }
            i++;
        }
        return maskedText;
    }

    public static int getToolbarHeight(Context context) {
        final TypedArray styledAttributes = context.getTheme().obtainStyledAttributes(
                new int[]{R.attr.actionBarSize});
        int toolbarHeight = (int) styledAttributes.getDimension(0, 0);
        styledAttributes.recycle();

        return toolbarHeight;
    }

    public static int getTabsHeight(Context context) {
        return (int) context.getResources().getDimension(R.dimen.actionBarSize);
    }

    public static int getStatusBarHeight(Context context) {
        int result = 0;
        int resourceId = context.getResources().getIdentifier("status_bar_height", "dimen", "android");
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT && resourceId > 0) {
            result = context.getResources().getDimensionPixelSize(resourceId);
        }
        return result;
    }

    public static boolean isAtLeastVersion(int version) {
        return Build.VERSION.SDK_INT >= version;
    }

    public static String hexString(Resources res) {
        Object resImpl = getPrivateField("android.content.res.Resources", "mResourcesImpl", res);
        Object o = resImpl != null ? resImpl : res;
        return "@" + Integer.toHexString(o.hashCode());
    }

    public static Object getPrivateField(String className, String fieldName, Object object) {
        try {
            Class c = Class.forName(className);
            Field f = c.getDeclaredField(fieldName);
            f.setAccessible(true);
            return f.get(object);
        } catch (Throwable e) {
            e.printStackTrace();
            return null;
        }
    }

    public static String removerAcentos(String str) {
        return Normalizer.normalize(str, Normalizer.Form.NFD).replaceAll("[^\\p{ASCII}]", "");
	}
	
    public static float convertDpToPixels(Context context, float dp) {
        return dp * context.getResources().getDisplayMetrics().density;
	}

    public static int getPixelsFromDp(Context context, float dp) {
        final float scale = context.getResources().getDisplayMetrics().density;
        return (int) (dp * scale + 0.5f);
    }
}
