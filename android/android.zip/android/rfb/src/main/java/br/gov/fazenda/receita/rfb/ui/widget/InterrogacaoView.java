package br.gov.fazenda.receita.rfb.ui.widget;

import java.util.ArrayList;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.view.View;
import br.gov.fazenda.receita.rfb.R;

import com.nineoldandroids.animation.ValueAnimator;
import com.nineoldandroids.animation.ValueAnimator.AnimatorUpdateListener;

public class InterrogacaoView extends View {

    Bitmap droid;       // The bitmap that all flakes use
    int numInterrogacaos = 0;  // Current number of flakes
    ArrayList<Interrogacao> flakes = new ArrayList<Interrogacao>(); // List of current flakes

    // Animator used to drive all separate flake animations. Rather than have potentially
    // hundreds of separate animators, we just use one and then update all flakes for each
    // frame of that single animation.
    ValueAnimator animator = ValueAnimator.ofFloat(0, 1);
    long startTime, prevTime; // Used to track elapsed time for animations and fps
    int frames = 0;     // Used to track frames per second
    Paint textPaint;    // Used for rendering fps text
    float fps = 0;      // frames per second
    Matrix m = new Matrix(); // Matrix used to translate/rotate each flake during rendering
    String fpsString = "";
    String numInterrogacaosString = "";

    /**
     * Constructor. Create objects used throughout the life of the View: the Paint and
     * the animator
     */
    public InterrogacaoView(Context context) {
        super(context);
        droid = BitmapFactory.decodeResource(getResources(), R.drawable.interrogacao3);
     //   textPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
      //  textPaint.setColor(Color.WHITE);
       // textPaint.setTextSize(24);

        // This listener is where the action is for the flak animations. Every frame of the
        // animation, we calculate the elapsed time and update every flake's position and rotation
        // according to its speed.
        animator.addUpdateListener(new AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator arg0) {
                long nowTime = System.currentTimeMillis();
                float secs = (float)(nowTime - prevTime) / 1000f;
                prevTime = nowTime;
                for (int i = 0; i < numInterrogacaos; ++i) {
                    Interrogacao flake = flakes.get(i);
                    flake.y += (flake.speed * secs);
                    if (flake.y > getHeight()) {
                        // If a flake falls off the bottom, send it back to the top
                        flake.y = 0 - flake.height;
                    }
                    flake.rotation = flake.rotation + (flake.rotationSpeed * secs);
                }
                // Force a redraw to see the flakes in their new positions and orientations
                invalidate();
            }
        });
        animator.setRepeatCount(ValueAnimator.INFINITE);
        animator.setDuration(3000);
    }

    int getNumInterrogacaos() {
        return numInterrogacaos;
    }

    private void setNumInterrogacaos(int quantity) {
        numInterrogacaos = quantity;
        numInterrogacaosString = "numInterrogacaos: " + numInterrogacaos;
    }

    /**
     * Add the specified number of droidflakes.
     */
    void addInterrogacaos(int quantity) {
        for (int i = 0; i < quantity; ++i) {
            flakes.add(Interrogacao.createInterrogacao(getWidth(), droid));
        }
        setNumInterrogacaos(numInterrogacaos + quantity);
    }

    /**
     * Subtract the specified number of droidflakes. We just take them off the end of the
     * list, leaving the others unchanged.
     */
    void subtractInterrogacaos(int quantity) {
        for (int i = 0; i < quantity; ++i) {
            int index = numInterrogacaos - i - 1;
            flakes.remove(index);
        }
        setNumInterrogacaos(numInterrogacaos - quantity);
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        // Reset list of droidflakes, then restart it with 8 flakes
        flakes.clear();
        numInterrogacaos = 0;
        if(w >= 480)
        	addInterrogacaos(8);
        else
        	addInterrogacaos(4);
        // Cancel animator in case it was already running
        animator.cancel();
        // Set up fps tracking and start the animation
        startTime = System.currentTimeMillis();
        prevTime = startTime;
        frames = 0;
        animator.start();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        // For each flake: back-translate by half its size (this allows it to rotate around its center),
        // rotate by its current rotation, translate by its location, then draw its bitmap
        for (int i = 0; i < numInterrogacaos; ++i) {
            Interrogacao interrogacao = flakes.get(i);
            m.setTranslate(-interrogacao.width/2, -interrogacao.height/2);
            m.postRotate(interrogacao.rotation);
            m.postTranslate(interrogacao.width/2 + interrogacao.x, interrogacao.height/2 + interrogacao.y);
            canvas.drawBitmap(interrogacao._bitmap, m, null);
        }
        // fps counter: count how many frames we draw and once a second calculate the
        // frames per second
        ++frames;
        long nowTime = System.currentTimeMillis();
        long deltaTime = nowTime - startTime;
        if (deltaTime > 1000) {
            float secs = (float) deltaTime / 1000f;
            fps = (float) frames / secs;
            fpsString = "fps: " + fps;
            startTime = nowTime;
            frames = 0;
        }
     //   canvas.drawText(numInterrogacaosString, getWidth() - 200, getHeight() - 50, textPaint);
     //   canvas.drawText(fpsString, getWidth() - 200, getHeight() - 80, textPaint);
    }

    public void pause() {
        // Make sure the animator's not spinning in the background when the activity is paused.
        animator.cancel();
    }

    public void resume() {
        animator.start();
    }
}
