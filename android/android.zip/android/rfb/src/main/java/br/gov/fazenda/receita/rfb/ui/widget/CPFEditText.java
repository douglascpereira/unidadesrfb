package br.gov.fazenda.receita.rfb.ui.widget;

import android.content.Context;
import android.util.AttributeSet;

public class CPFEditText extends ExtendedEditText {

	public CPFEditText(Context context) {
		super(context);
		maxLength = 11;
		initialize(context);
	}
	
	public CPFEditText(final Context context, final AttributeSet attributeSet) {
		super(context, attributeSet);
		maxLength = 11;
		initialize(context);
	}
}
