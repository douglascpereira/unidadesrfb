package br.gov.fazenda.receita.rfb.util;

import android.os.Build;

public class Constantes {
	
	public static final String SISTEMA_OPERACIONAL = new ObfuscatedString(new long[] { 0x556D2DB567B5C8C6L, 0x58AF33E6EBFFBFF5L }).toString();
	public static final String VERSAO = Build.VERSION.RELEASE;
	public static final String DISPOSITIVO = Build.MODEL;

	public static final int TIMEOUT_SERVICO = 60000;
	
	// a senha é: Sup3RbP4ssCr1t0grPhABr4sil
	public static final String HASH_KEY = new ObfuscatedString(new long[] {0x94CD252918E72F58L, 0xF3313EF459AE89ECL, 0x15B29F0A6A64120L, 0xBC2508ADFA51D64FL, 0x8BC48AA5D81571A9L}).toString();
	
	public static enum Ambiente {
		DEV("10.200.238.227", 8443), 
		HOM("movel02.hom.receita.fazenda.gov.br",443),
		PROD("movel02.receita.fazenda.gov.br", 443);
		
		private String url;
		private int porta;
		private Ambiente(String url, int porta) {
			this.url = url;
			this.porta = porta;
		}
		
		public String getUrl(){
			return url;
		}
		public int getPorta(){
			return porta;
		}
	}

}