package br.gov.fazenda.receita.rfb.util;

import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class DataUtil {

	public static final Locale LOC_PtBr = new Locale("pt", "BR");

	public static final String DEFAULT_DATE_PATTERN = "dd/MM/yyyy";
	
	public static final String DEFAULT_DATE_TIME_PATTERN = "dd/MM/yyyy HH:mm:ss";

	private static final SimpleDateFormat SDF_DEFAULT_DATA = new SimpleDateFormat(DEFAULT_DATE_PATTERN, LOC_PtBr);
	
	private static final SimpleDateFormat SDF_DEFAULT_DATA_TIME = new SimpleDateFormat(DEFAULT_DATE_TIME_PATTERN, LOC_PtBr);

	public static List<String> LISTA_MES = Collections.unmodifiableList(Arrays.asList("Janeiro", "Fevereiro", "Março",
			"Abril", "Maio", "Junho", "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro"));

	public static List<String> LISTA_MES_REDUZIDO = Collections.unmodifiableList(Arrays.asList("JAN", "FEV", "MAR",
			"ABR", "MAI", "JUN", "JUL", "AGO", "SET", "OUT", "NOV", "DEZ"));

	public static String formatDate(Date data) {
		try {
			return SDF_DEFAULT_DATA.format(data);
		} catch (Exception e) {
		}
		return null;
	}
	
	public static String formatDateTime(Date data) {
		try {
			return SDF_DEFAULT_DATA_TIME.format(data);
		} catch (Exception e) {
		}
		return null;
	}

	public static Date parseDate(String data) {
		try {
			return SDF_DEFAULT_DATA.parse(data);
		} catch (Exception e) {
		}
		return null;
	}
	
	public static Date parseDateTime(String data) {
		try {
			return SDF_DEFAULT_DATA_TIME.parse(data);
		} catch (Exception e) {
		}
		return null;
	}

	public static int getNumeroMes(String mesReduzido) {
		return LISTA_MES_REDUZIDO.indexOf(mesReduzido);
	}

	public static String getMes(String mesReduzido) {
		int index = LISTA_MES_REDUZIDO.indexOf(mesReduzido);
		return LISTA_MES.get(index);
	}
}
