package br.gov.fazenda.receita.rfb.util;

public class CEP {

    public static String formatar(String cep) {
        if (cep.contains("-"))
            return cep;
        else {
            String cepFormatado = null;
            cepFormatado = cep.substring(0, 5) + "-" + cep.substring(5, 8);
            return cepFormatado;
        }
    }

    public static String formatarCompleto(String cep) {
        String cepFormatado = null;
        if (Strings.isNotEmpty(cep)) {
            if (cep.length() == 7)
                cep = "0" + cep;
            cepFormatado = cep.substring(0, 2) + "." + cep.substring(2, 5) + "-" + cep.substring(5, 8);
        }
        return cepFormatado;
    }
}
