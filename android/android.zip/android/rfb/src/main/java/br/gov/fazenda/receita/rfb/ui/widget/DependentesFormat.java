package br.gov.fazenda.receita.rfb.ui.widget;

import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnFocusChangeListener;
import android.widget.EditText;

public class DependentesFormat implements TextWatcher {
	private EditText et;
	
	public DependentesFormat(EditText et) {
		this.et = et;
		addListeners();
	}
	
	@Override
	public void afterTextChanged(Editable s) {	
	}
		
	@Override
	public void beforeTextChanged(CharSequence s, int start, int count,	int after) {
	}
	@Override
	public void onTextChanged(CharSequence s, int start, int before, int count) {
//		Log.i("ontext", s.toString());
	}
	
	private void addListeners() {
		et.setOnFocusChangeListener(new OnFocusChangeListener() {
			
			@Override
			public void onFocusChange(View v, boolean hasFocus) {
				if (hasFocus){
					et.setText(null);
					et.setSelection(et.getText().length());
				}
				else 
					if(et.getText().length() <= 0) {
						et.setText("0");		
					}		
					
			}
		});
		
		et.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				et.setSelection(et.getText().length());
			}
		});
	}

}
