package br.gov.fazenda.receita.rfb.ui.widget;

import android.content.Context;
import android.util.AttributeSet;
import br.gov.fazenda.receita.rfb.util.Mask;

public class CNPJMaskEditText extends ExtendedEditText {

	public CNPJMaskEditText(Context context) {
		super(context);
		maxLength = 18;
		initialize(context);
		editText.addTextChangedListener(Mask.insert("##.###.###/####-##", editText));
	}
	
	public CNPJMaskEditText(final Context context, final AttributeSet attributeSet) {
		super(context, attributeSet);
		maxLength = 18;
		initialize(context);
		editText.addTextChangedListener(Mask.insert("##.###.###/####-##", editText));
	}
	
}
