package br.gov.fazenda.receita.rfb.model;

import com.google.gson.Gson;

import java.io.Serializable;

import br.gov.fazenda.receita.rfb.util.Constantes;
import br.gov.fazenda.receita.rfb.util.Hash;

public class HeaderPadrao implements Serializable {

    private static final long serialVersionUID = 1L;

    public String aplicativo;
    public String so;
    public String versaoSO;
    public String versaoAPP;
    public String dispositivo;
    public String token;
    public String contentType;
    public String userAgent;
    public String acceptEncoding;
    public String acceptCharset;
    public String rest;

    public HeaderPadrao() {
    }

    @Override
    public String toString() {
        return new Gson().toJson(this);
    }

    public HeaderPadrao(String aplicativo, String versaoSO, String dispositivo, String versaoApp) {
        this.aplicativo = aplicativo;
        this.versaoSO = versaoSO;
        this.dispositivo = dispositivo;
        this.versaoAPP = versaoApp;
        this.so = "Android";
        this.contentType = "application/json";
    }

    public HeaderPadrao(String aplicativo, String versaoSO, String dispositivo, String versaoApp, boolean rest) {
        this(aplicativo, versaoSO, dispositivo, versaoApp);
        this.rest = String.valueOf(rest);
    }

    public HeaderPadrao(String aplicativo, String versaoSO, String dispositivo, String versaoApp, String sementeHash) {
        this(aplicativo, versaoSO, dispositivo, versaoApp);
        this.token = Hash.generateHash(Constantes.HASH_KEY, sementeHash);
    }

    public HeaderPadrao(String aplicativo, String versaoSO, String dispositivo, String versaoApp, String sementeHash, boolean rest) {
        this(aplicativo, versaoSO, dispositivo, versaoApp, sementeHash);
        this.rest = String.valueOf(rest);
    }

    public HeaderPadrao(String aplicativo, String versaoSO, String dispositivo, String versaoApp, String sementeHash, String contentType) {
        this.aplicativo = aplicativo;
        this.versaoSO = versaoSO;
        this.dispositivo = dispositivo;
        this.versaoAPP = versaoApp;
        this.so = "Android";
        this.contentType = contentType;
        if (contentType.equals("application/x-www-form-urlencoded; charset=utf-8")) {
            this.acceptCharset = "utf-8";
            this.acceptEncoding = "identity";
            this.userAgent = "Mozilla/5.0";
        }
        this.token = Hash.generateHash(Constantes.HASH_KEY, sementeHash);
    }

    public HeaderPadrao(String aplicativo, String versaoSO, String dispositivo, String versaoApp, String sementeHash, String contentType, boolean rest) {
        this(aplicativo, versaoSO, dispositivo, versaoApp, sementeHash, contentType);
        this.rest = String.valueOf(rest);
    }

    public HeaderPadrao(String userAgent) {
        this.contentType = "application/x-www-form-urlencoded";
        this.userAgent = userAgent;
    }
}
