package br.gov.fazenda.receita.rfb.ui.adapter;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import android.content.Context;
import android.view.LayoutInflater;
import android.widget.BaseAdapter;

/**
 * Adapter para exibição da lista de orientações.
 * 
 * @author SERPRO
 * @param <T>
 * @since 1.0.0
 */
public abstract class RFBBaseAdapter<T> extends BaseAdapter {
	
	protected List<T> list;
	protected LayoutInflater inflater;
	protected Context context;
	protected HashSet<Integer> checkedItems;
	protected boolean multiMode;

	public RFBBaseAdapter(final Context context, final List<T> list) {
		this.context = context;
		this.inflater = LayoutInflater.from(context);
		this.list = list;
		this.checkedItems = new HashSet<Integer>();
	}
	
	public void enterMultiMode(){
        this.multiMode = true;
        this.notifyDataSetChanged();
    }
	
	public void exitMultiMode() {
        this.checkedItems.clear();
        this.multiMode = false;
        this.notifyDataSetChanged();
    }
	
	public void setChecked(int pos, boolean checked) {
        if (checked) {
            this.checkedItems.add(Integer.valueOf(pos));
        } else {
            this.checkedItems.remove(Integer.valueOf(pos));
        }
        if (this.multiMode) {
            this.notifyDataSetChanged();
        }
    }
	
	public void toggleSingleChecked(int pos){
		final Integer v = Integer.valueOf(pos);
		if (this.checkedItems.contains(v)) {
			this.checkedItems.remove(v);
		} else {
			if (this.checkedItems.size() > 0) {
				this.checkedItems.clear();
			}
			this.checkedItems.add(v);
		}
		this.notifyDataSetChanged();
	}
	
	public void toggleChecked(int pos) {
        final Integer v = Integer.valueOf(pos);
        if (this.checkedItems.contains(v)) {
            this.checkedItems.remove(v);
        } else {
            this.checkedItems.add(v);
        }
        this.notifyDataSetChanged();
    }

    public int getCheckedItemCount() {
        return this.checkedItems.size();
    }
	
	public boolean isChecked(int pos) {
        return this.checkedItems.contains(Integer.valueOf(pos));
    }

	public T getFirstCheckedItem() {
        for (Integer i : this.checkedItems) {
            return this.list.get(i.intValue());
        }
        return null;
    }

    public Set<Integer> getCheckedItems() {
        return this.checkedItems;
    }

    public void clear() {
        this.list.clear();
    }
    
    public void updateData(T[] data) {
        for (int i = 0; i < data.length; i++) {
            this.list.add(data[i]);
        }
        this.checkedItems.clear();
        this.notifyDataSetChanged();
    }
    
    public void insert(T item, int position){
    	this.list.add(position, item);
    }
    
    public void remove(T item){
    	list.remove(item);
    }    
    
	@Override
	public int getCount() {
		return list.size();
	}

	@Override
	public T getItem(int position) {
        try {
            return list.get(position);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
	}

	@Override
	public long getItemId(int position) {
		return position;
	}
	
	@Override
    public boolean hasStableIds() {
        return true;
    }
}
