package br.gov.fazenda.receita.rfb.ui.listeners;

import android.text.Editable;
import android.text.TextWatcher;
import android.widget.EditText;
import java.util.HashSet;
import java.util.Set;

import br.gov.fazenda.receita.rfb.util.Utils;

public class MaskEditTextChangedListener implements TextWatcher{

    private static MaskEditTextChangedListener instance;

    private String mMask;
    private EditText mEditText;
    private Set<String> symbolMask = new HashSet<String>();
    private boolean isUpdating;
    private String old = "";

    public MaskEditTextChangedListener(String mask, EditText editText) {
        mMask = mask;
        mEditText = editText;
        initSymbolMask();
    }

    private void initSymbolMask(){
        for (int i=0; i < mMask.length(); i++){
            char ch = mMask.charAt(i);
            if (ch != '#')
                symbolMask.add(String.valueOf(ch));
        }
    }

    @Override
    public void onTextChanged(CharSequence s, int start, int before, int count) {
        String str = Utils.unmask(s.toString());
        String mascara = "";

        if (isUpdating) {
            old = str;
            isUpdating = false;
            return;
        }

        if(str.length() > 0 &&  str.length() <= 10)
            mascara = Utils.mask("(##)####-####",str);
        else
            if(str.length() >= 11)
                mascara = Utils.mask("(##)#####-####",str);
            else
                mascara = s.toString();
        if(mascara.endsWith("-") || mascara.endsWith(")")){
            mascara = mascara.substring(0, mascara.length()-1);
        }


        isUpdating = true;

        mEditText.setText(mascara);
        mEditText.setSelection(mascara.length());
    }

    @Override
    public void beforeTextChanged(CharSequence s, int start, int count, int after) {

    }


    @Override
    public void afterTextChanged(Editable s) {

    }
}