package br.gov.fazenda.receita.rfb.util;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;

public class Strings {

	public static final String EMPTY_STRING = "";

	/**
	 * Substituir do texto os elementos HTML especiais, como &nbsp;, pelo valor
	 * correspondente em ASCII. Código original em
	 * http://www.rgagnon.com/javadetails/java-0307.html.
	 * 
	 * @param source
	 *            Código que terá o texto trocado.
	 * @param start
	 *            Onde iniciar a troca.
	 * @return Texto com os valores convertidos.
	 */
	public static String desconverterElementosHTMLEspeciais(String source, int start) {
		HashMap<String, String> htmlEntities;
		htmlEntities = new HashMap<String, String>();
		htmlEntities.put("&lt;", "<");
		htmlEntities.put("&gt;", ">");
		htmlEntities.put("&amp;", "&");
		htmlEntities.put("&quot;", "\"");
		htmlEntities.put("&agrave;", "à");
		htmlEntities.put("&Agrave;", "À");
		htmlEntities.put("&atilde;", "ã");
		htmlEntities.put("&Atilde;", "Ã");
		htmlEntities.put("&aacute;", "á");
		htmlEntities.put("&Aacute;", "Á");
		htmlEntities.put("&acirc;", "â");
		htmlEntities.put("&auml;", "ä");
		htmlEntities.put("&Auml;", "Ä");
		htmlEntities.put("&Acirc;", "Â");
		htmlEntities.put("&aring;", "å");
		htmlEntities.put("&Aring;", "Å");
		htmlEntities.put("&aelig;", "æ");
		htmlEntities.put("&AElig;", "Æ");
		htmlEntities.put("&ccedil;", "ç");
		htmlEntities.put("&Ccedil;", "Ç");
		htmlEntities.put("&eacute;", "é");
		htmlEntities.put("&Eacute;", "É");
		htmlEntities.put("&egrave;", "è");
		htmlEntities.put("&Egrave;", "È");
		htmlEntities.put("&ecirc;", "ê");
		htmlEntities.put("&Ecirc;", "Ê");
		htmlEntities.put("&euml;", "ë");
		htmlEntities.put("&Euml;", "Ë");
		htmlEntities.put("&iuml;", "ï");
		htmlEntities.put("&Iuml;", "Ï");
		htmlEntities.put("&iacute;", "í");
		htmlEntities.put("&Iacute;", "Í");
		htmlEntities.put("&ocirc;", "ô");
		htmlEntities.put("&Ocirc;", "Ô");
		htmlEntities.put("&otilde;", "õ");
		htmlEntities.put("&Otilde;", "Õ");
		htmlEntities.put("&oacute;", "ó");
		htmlEntities.put("&Oacute;", "Ó");
		htmlEntities.put("&uacute;", "ú");
		htmlEntities.put("&Uacute;", "Ú");
		htmlEntities.put("&ouml;", "ö");
		htmlEntities.put("&Ouml;", "Ö");
		htmlEntities.put("&oslash;", "ø");
		htmlEntities.put("&Oslash;", "Ø");
		htmlEntities.put("&szlig;", "ß");
		htmlEntities.put("&ugrave;", "ù");
		htmlEntities.put("&Ugrave;", "Ù");
		htmlEntities.put("&ucirc;", "û");
		htmlEntities.put("&Ucirc;", "Û");
		htmlEntities.put("&uuml;", "ü");
		htmlEntities.put("&Uuml;", "Ü");
		htmlEntities.put("&nbsp;", " ");
		htmlEntities.put("&copy;", "\u00a9");
		htmlEntities.put("&reg;", "\u00ae");
		htmlEntities.put("&euro;", "\u20a0");
		htmlEntities.put("&ordm;", "º");
		htmlEntities.put("&ordf;", "ª");
		htmlEntities.put("&mdash;", "—");
		htmlEntities.put("&ndash;", "–");
		htmlEntities.put("&bull;", "•");
		htmlEntities.put("&#39;", "'");

		int i, j;
		i = source.indexOf("&", start);
		if (i > -1) {
			j = source.indexOf(";", i);
			if (j > i) {
				String entityToLookFor = source.substring(i, j + 1);
				String value = (String) htmlEntities.get(entityToLookFor);
				if (value != null) {
					source = new StringBuffer().append(source.substring(0, i)).append(value)
							.append(source.substring(j + 1)).toString();
				}
				return desconverterElementosHTMLEspeciais(source, i + 1);
			}
		}
		return source;
	}

	public static final String converterParaElementosHTMLEspeciais(String source) {
		HashMap<Character, String> htmlEntities;
		htmlEntities = new HashMap<Character, String>();
		htmlEntities.put('\\', "&quot;");
		htmlEntities.put('à', "&agrave;");
		htmlEntities.put('À', "&Agrave;");
		htmlEntities.put('ã', "&atilde;");
		htmlEntities.put('Ã', "&Atilde;");
		htmlEntities.put('á', "&aacute;");
		htmlEntities.put('Á', "&Aacute;");
		htmlEntities.put('â', "&acirc;");
		htmlEntities.put('ä', "&auml;");
		htmlEntities.put('Ä', "&Auml;");
		htmlEntities.put('Â', "&Acirc;");
		htmlEntities.put('å', "&aring;");
		htmlEntities.put('Å', "&Aring;");
		htmlEntities.put('æ', "&aelig;");
		htmlEntities.put('Æ', "&AElig;");
		htmlEntities.put('ç', "&ccedil;");
		htmlEntities.put('Ç', "&Ccedil;");
		htmlEntities.put('é', "&eacute;");
		htmlEntities.put('É', "&Eacute;");
		htmlEntities.put('è', "&egrave;");
		htmlEntities.put('È', "&Egrave;");
		htmlEntities.put('ê', "&ecirc;");
		htmlEntities.put('Ê', "&Ecirc;");
		htmlEntities.put('ë', "&euml;");
		htmlEntities.put('Ë', "&Euml;");
		htmlEntities.put('ï', "&iuml;");
		htmlEntities.put('Ï', "&Iuml;");
		htmlEntities.put('í', "&iacute;");
		htmlEntities.put('Í', "&Iacute;");
		htmlEntities.put('ô', "&ocirc;");
		htmlEntities.put('Ô', "&Ocirc;");
		htmlEntities.put('õ', "&otilde;");
		htmlEntities.put('Õ', "&Otilde;");
		htmlEntities.put('ó', "&oacute;");
		htmlEntities.put('Ó', "&Oacute;");
		htmlEntities.put('ú', "&uacute;");
		htmlEntities.put('Ú', "&Uacute;");
		htmlEntities.put('ö', "&ouml;");
		htmlEntities.put('Ö', "&Ouml;");
		htmlEntities.put('ø', "&oslash;");
		htmlEntities.put('Ø', "&Oslash;");
		htmlEntities.put('ß', "&szlig;");
		htmlEntities.put('ù', "&ugrave;");
		htmlEntities.put('Ù', "&Ugrave;");
		htmlEntities.put('û', "&ucirc;");
		htmlEntities.put('Û', "&Ucirc;");
		htmlEntities.put('ü', "&uuml;");
		htmlEntities.put('Ü', "&Uuml;");
		htmlEntities.put('%', "&#37;");
		htmlEntities.put('—', "&mdash;");
		htmlEntities.put('–', "&ndash;");
		htmlEntities.put('º', "&ordm;");
		htmlEntities.put('ª', "&ordf;");
		htmlEntities.put('§', "&sect;");
		htmlEntities.put('“', "&quot;");
		htmlEntities.put('”', "&quot;");
		htmlEntities.put('•', "&bull;");

		int length = source.length();
		StringBuilder sb = new StringBuilder();
		for (int i = 0; i < length; i++) {
			char ch = source.charAt(i);
			if (htmlEntities.containsKey(ch)) {
				String o = htmlEntities.get(ch);
				sb.append(o);
			} else {
				sb.append(ch);
			}
		}
		return sb.toString();
	}

	public static String replaceNULL(String string) {
		return (string == null ? "" : string);
	}

	/**
	 * Verifica se a String "str" é vazia, ou seja, é null ou igual da constante
	 * EMPTY_STRING.
	 * 
	 * @param str
	 *            String a ser testada.
	 * @return Verdadeiro ou falso.
	 */
	public static boolean isEmpty(String str) {
		return str == null || EMPTY_STRING.equals(str.trim());
	}

	/**
	 * Verifica se a String "str" não é vazia, ou seja, não é null e diferente
	 * da constante EMPTY_STRING.
	 * 
	 * @param str
	 *            String a ser testada.
	 * @return Verdadeiro ou falso.
	 */

	public static boolean isNotEmpty(String str) {
		return !isEmpty(str);
	}

	/**
	 * Adiciona o caracter informado a esquerda da string até que esta atinja do
	 * tamanho de caractes desejado. Caso o parametro size seja menor que o
	 * tamanho de valor, esta sera truncada.
	 * 
	 * @param valor
	 *            String original
	 * @param c
	 *            Caracter a ser adicionado
	 * @param size
	 *            Numero de caracteres da strig gerada
	 * @return String com o caracter informado a esquerda do parametro valor
	 */
	public static String addLeft(final String valor, char c, int size) {
		if (valor == null) {
			return EMPTY_STRING;
		}
		return right(echo(c, size) + valor, size);
	}

	/**
	 * Adiciona o caracter informado a direta da string ate que esta atinja do
	 * tamanho de caractes desejado. Caso o parametro size seja menor que o
	 * tamanho de valor, esta sera truncada.
	 * 
	 * @param valor
	 *            String original
	 * @param c
	 *            Caracter a ser adicionado
	 * @param size
	 *            Numero de caracteres da strig gerada
	 * @return String com o caracter a direita do parametro valor
	 */
	public static String addRight(final String valor, char c, int size) {
		if (valor == null) {
			return EMPTY_STRING;
		}
		return left(valor + echo(c, size), size);
	}

	/**
	 * Cria uma string de um unico caracter repetidas vezes. Exemplo:
	 * 
	 * <pre>
	 * echo('0', 10) = &quot;0000000000&quot;
	 * </pre>
	 * 
	 * @param character
	 *            Caracter a ser repetido
	 * @param size
	 *            Numero de caracteres
	 * @return String de um unico caracter repetidas vezes
	 */
	public static String echo(char character, int size) {
		if (size <= 0) {
			return EMPTY_STRING;
		}

		char[] characterVector = new char[size];
		for (int i = 0; i < size; i++) {
			characterVector[i] = character;
		}

		return new String(characterVector);
	}

	/**
	 * Retorna os n caracteres à direita de str. Caso o parametro n seja menor
	 * que 0 sera retorna do uma string vazia.
	 * 
	 * @param str
	 *            string original
	 * @param n
	 *            numero de caracteres
	 * @return substring
	 */
	public static String right(String str, int n) {
		if (str == null || n < 0) {
			return EMPTY_STRING;
		} else if (n > str.length()) {
			return str;
		}
		return str.substring(str.length() - n, str.length());
	}

	/**
	 * Retorna os n caracteres a esquerda de str. Caso o parametro n seja menor
	 * que 0 sera retorna do uma string vazia.
	 * 
	 * @param str
	 *            string original
	 * @param n
	 *            numero de caracteres
	 * @return substring
	 */
	public static String left(String str, int n) {
		if (str == null || n < 0) {
			return EMPTY_STRING;
		} else if (n > str.length()) {
			return str;
		}
		return str.substring(0, n);
	}

	/**
	 * Verifica se todos os caracteres são letras.
	 * 
	 * @param valor
	 *            String.
	 * @return verdadeiro ou falso.
	 */
	public static Boolean somenteLetras(String valor) {
		if (isNotEmpty(valor)) {
			for (int i = 0; i < valor.length(); i++) {
				if (!Character.isLetter(valor.charAt(i)))
					return false;
			}
			return true;
		}
		return false;
	}

	/**
	 * Elimina todos os acentos de um string.
	 * 
	 * @param valor
	 *            string
	 * @return string sem acentos
	 */
	public static String eliminaAcentos(String valor) {
		final String comAcentos = "ÄÅÁÂÀÃäáâàãÉÊËÈéêëèÍÎÏÌíîïìÖÓÔÒÕöóôòõÜÚÛüúûùÇç";
		final String semAcentos = "AAAAAAaaaaaEEEEeeeeIIIIiiiiOOOOOoooooUUUuuuuCc";
		String resultado = valor;

		if (isNotEmpty(valor)) {
			for (int i = 0; i < comAcentos.length(); i++) {
				resultado = resultado.replace(comAcentos.charAt(i), semAcentos.charAt(i));
			}
			return resultado;
		}

		return EMPTY_STRING;
	}

	/**
	 * Verifica se uma string é composta somente por digitos.
	 * 
	 * @param valor
	 *            Valor a ser testado.
	 * @return True caso sehja composta apenas por dígitos, false caso
	 *         contrário.
	 */
	public static boolean isNumeric(String valor) {
		return java.util.regex.Pattern.matches("\\d+", valor);
	}
	
	/**
	 * Converte uma string em double
	 * 
	 * @param valor
	 *            Valor a ser convertido.
	 * @return valor em double
	 */
	public static double convertToDouble(String valor) {
		valor = valor.replace(".", "");
		valor = valor.replace(",", ".");
		return Double.valueOf(valor);
	}

	public static ArrayList<String> getBadWordsList() {
		return new ArrayList<String>(Arrays.asList(new String[]{"ANUS", "ÂNUS", "BABA-OVO",
				"BABAOVO", "BABACA", "BACURA", "BAGOS", "BAITOLA", "BEBUM", "BESTA", "BICHA", "BISCA",
				"BIXA", "BOAZUDA", "BOCETA", "BOCO", "BOCÓ", "BOIOLA", "BOLAGATO", "BOQUETE", "BOLCAT",
				"BOSSETA", "BOSTA", "BOSTANA", "BRECHA", "BREXA", "BRIOCO", "BRONHA", "BUCA", "BUCETA",
				"BUNDA", "BUNDUDA", "BURRA", "BURRO", "BUSSETA", "CACHORRA", "CACHORRO", "CADELA", "CAGA",
				"CAGADO", "CAGAO", "CAGONA", "CANALHA", "CARALHO", "CASSETA", "CASSETE", "CHECHECA", "CHERECA",
				"CHIBUMBA", "CHIBUMBO", "CHIFRUDA", "CHIFRUDO", "CHOTA", "CHOCHOTA", "CHUPADA", "CHUPADO",
				"CLITORIS", "CLITÓRIS", "COCAINA", "COCAÍNA", "COCO", "COCÔ", "CORNA", "CORNO", "CORNUDA",
				"CORNUDO", "CORRUPTA", "CORRUPTO", "CRETINA", "CRETINO", "CRUZ-CREDO", "CU ", "CÚ", "CULHAO",
				"CULHÃO", "CULHÕES", "CURALHO", "CUZAO", "CUZÃO", "CUZUDA", "CUZUDO", "DEBIL", "DEBILOIDE",
				"DEFUNTO", "DEMONIO", "DEMÔNIO", "DIFUNTO", "DOIDA", "DOIDO", "EGUA", "ÉGUA", "ESCROTA",
				"ESCROTO", "ESPORRADA", "ESPORRADO", "ESPORRO", "ESPÔRRO", "ESTUPIDA", "ESTÚPIDA", "ESTUPIDEZ",
				"ESTUPIDO", "ESTÚPIDO", "FEDIDA", "FEDIDO", "FEDOR", "FEDORENTA", "FEIA", "FEIO", "FEIOSA",
				"FEIOSO", "FEIOZA", "FEIOZO", "FELACAO", "FELAÇÃO", "FENDA", "FODA", "FODAO", "FODÃO",
				"FODE", "FODIDA", "FODIDO", "FORNICA", "FUDENDO", "FUDECAO", "FUDEÇÃO", "FUDIDA", "FUDIDO",
				"FURADA", "FURADO", "FURAO", "FURÃO", "FURNICA", "FURNICAR", "FURO", "FURONA", "GAIATA",
				"GAIATO", "GAY", "GONORREA", "GONORREIA", "GOSMA", "GOSMENTA", "GOSMENTO", "GRELINHO",
				"GRELO", "HOMO-SEXUAL", "HOMOSEXUAL", "HOMOSSEXUAL", "IDIOTA", "IDIOTICE", "IMBECIL",
				"ISCROTA", "ISCROTO", "JAPA", "LADRA", "LADRAO", "LADRÃO", "LADROEIRA", "LADRONA",
				"LALAU", "LEPROSA", "LEPROSO", "LESBICA", "LÉSBICA", "MACACA", "MACACO", "MACHONA",
				"MACHORRA", "MANGUACA", "MANGUAÇA", "MASTURBA", "MELECA", "MERDA", "MIJA", "MIJADA",
				"MIJADO", "MIJO", "MOCREA", "MOCRÉA", "MOCREIA", "MOCRÉIA", "MOLECA", "MOLEQUE", "MONDRONGA",
				"MONDRONGO", "NABA", "NADEGA", "NOJEIRA", "NOJENTA", "NOJENTO", "NOJO", "OLHOTA", "OTARIA",
				"OTÁRIA", "OTARIO", "OTÁRIO", "PACA", "PASPALHA", "PASPALHAO", "PASPALHO", "PAU ", "PEIA",
				"PEIDO", "PEMBA", "PENIS", "PÊNIS", "PENTELHA", "PENTELHO", "PERERECA", "PERU", "PERÚ",
				"PICA", "PICAO", "PICÃO", "PILANTRA", "PIRANHA", "PIROCA", "PIROCO", "PIRU", "PORRA",
				"PREGA", "PROSTIBULO", "PROSTÍBULO", "PROSTITUTA", "PROSTITUTO", "PUNHETA", "PUNHETAO",
				"PUNHETÃO", "PUS", "PUSTULA", "PÚSTULA", "PUTA", "PUTO", "PUXA-SACO", "PUXASACO", "RABAO",
				"RABÃO", "RABO", "RABUDA", "RABUDAO", "RABUDÃO", "RABUDO", "RABUDONA", "RACHA", "RACHADA",
				"RACHADAO", "RACHADÃO", "RACHADINHA", "RACHADINHO", "RACHADO", "RAMELA", "REMELA", "RETARDADA",
				"RETARDADO", "RIDICULA", "RIDÍCULA", "ROLA", "ROLINHA", "ROSCA", "SACANA", "SAFADA", "SAFADO",
				"SAPATAO", "SAPATÃO", "SIFILIS", "SÍFILIS", "SIRIRICA", "TARADA", "TARADO", "TESTUDA", "TEZAO",
				"TEZÃO", "TEZUDA", "TEZUDO", "TROCHA", "TROLHA", "TROUCHA", "TROUXA", "TROXA", "VACA",
				"VAGABUNDA", "VAGABUNDO", "VAGINA", "VEADA", "VEADAO", "VEADÃO", "VEADO", "VIADA", "VIADO",
				"VIADAO", "VIADÃO", "XAVASCA", "XERERECA", "XEXECA", "XIBIU", "XIBUMBA", "XOTA", "XOCHOTA",
				"XOXOTA", "XANA", "XANINHA"}));
	}
}
