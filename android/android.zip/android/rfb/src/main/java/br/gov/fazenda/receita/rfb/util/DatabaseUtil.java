package br.gov.fazenda.receita.rfb.util;

import com.alienlabz.activerecord.Model;

public class DatabaseUtil {

	private DatabaseUtil() {

	}

	public static void gravarHistorico(Model result, int maxRegistros) {

		int qtdConsultas = Model.count(result.getClass());

		if (qtdConsultas >= maxRegistros) {
			Model.findFirst(result.getClass()).delete();
		}
		result.save();
	}
	
	public static void limparHistorico(Model result) {
		int qtdConsultas = Model.count(result.getClass());
		
		while (qtdConsultas > 0) {
			Model.findFirst(result.getClass()).delete();
			qtdConsultas = qtdConsultas -1;
		}
	}
	
	private static boolean gravar(Model result, int maxRegistros) {
		boolean retorno = false;
		
		int qtdConsultas = Model.count(result.getClass());
		
		if (qtdConsultas >= maxRegistros) {
			retorno = false;
		} else {
			result.save();
			retorno = true;
		}
		
		return retorno;
	}
	
	public static boolean gravarFavorito(Model result, int maxRegistros) {
		return gravar(result, maxRegistros);
	}
	
	public static boolean gravarAcompanhamento(Model result, int maxRegistros) {
		return gravar(result, maxRegistros);
	}
	
	private static void excluir(Model result) {
		result.delete();
	}
	
	public static void excluirFavorito(Model result) {
		excluir(result);
	}
	
	public static void excluirAcompanhamento(Model result) {
		excluir(result);
	}
}
