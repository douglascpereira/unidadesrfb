package br.gov.fazenda.receita.rfb.ui.activity;

import android.app.ProgressDialog;
import android.content.Context;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.view.ActionMode;
import androidx.appcompat.widget.Toolbar;
import android.util.TypedValue;
import android.view.Menu;
import android.view.MenuItem;
import android.view.inputmethod.InputMethodManager;
import android.widget.AbsListView;
import android.widget.ListView;

import com.alienlabz.activerecord.Model;

import java.util.List;

import br.gov.fazenda.receita.rfb.R;
import br.gov.fazenda.receita.rfb.ui.adapter.RFBBaseAdapter;
import br.gov.fazenda.receita.rfb.util.DatabaseUtil;
import de.timroes.swipetodismiss.SwipeDismissList;
import de.timroes.swipetodismiss.SwipeDismissList.Undoable;

public abstract class RFBListActivity<T> extends AppCompatActivity implements ActionMode.Callback {

	protected InputMethodManager inputMethodManager;

	protected RFBBaseAdapter<T> listAdapter;
	protected List<T> listData;
	
	protected SwipeDismissList mSwipeList;
	protected SwipeDismissList.UndoMode mode;

	protected ProgressDialog dialog;

	protected ActionMode mActionMode;

	protected Toolbar toolBar;

	protected abstract void initToolBar();

	protected abstract void updateData();
		
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		mode = SwipeDismissList.UndoMode.SINGLE_UNDO;
		inputMethodManager = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
	}

	@Override
	protected void onDestroy() {
		super.onDestroy();

		if(dialog != null)
			dialog.dismiss();
	}

	@Override
	protected void onPause() {
		super.onPause();
		
		if (mSwipeList != null)
			mSwipeList.discardUndo();
		
		if (this.mActionMode != null)
			this.mActionMode.finish();
		
	}

	@Override
	protected void onResume() {
		super.onResume();
		updateData();
	}

	protected void initSwipeListView(ListView listView) {
		initSwipeListView(listView, true);
	}
	
	protected void initSwipeListView(final ListView listView, final boolean useDiscardDefault) {
		mSwipeList = new SwipeDismissList(
				// 1st parameter is the ListView you want to use
				listView,
				// 2nd parameter is an OnDismissCallback, that handles the deletion
				// and undo of list items. It only needs to implement onDismiss.
				// This method can return an Undoable (then this deletion can be undone)
				// or null (if the user shouldn't get the possibility to undo the
				// deletion).
				new SwipeDismissList.OnDismissCallback() {
					/**
					 * Will be called, whenever the user swiped out an list item.
					 *
					 * @param listView The {@link ListView} that the item was deleted
					 * from.
					 * @param position The position of the item, that was deleted.
					 * @return An {@link Undoable} or {@code null} if this deletion
					 * shouldn't be undoable.
					 */
					public Undoable onDismiss(final AbsListView listView, final int position) {

						// Get item that should be deleted from the adapter.
						final T item = (T) listAdapter.getItem(position);
						// Delete that item from the adapter.
						
						if (mActionMode != null) {
							mActionMode.finish();
						}
						
						listAdapter.remove(item);
						listView.setAdapter(listAdapter);
						listAdapter.notifyDataSetChanged();
						

						// Return an Undoable, for that deletion. If you write return null
						// instead, this deletion won't be undoable.
						return new Undoable() {
							/**
							 * Optional method. If you implement this method, the
							 * returned String will be presented in the undo view to the
							 * user.
							 */
							@Override
							public String getTitle() {
								return getString(R.string.swipedismiss_mesagem_sucesso);
							}

							/**
							 * Will be called when the user hits undo. You want to
							 * reinsert the item to the adapter again. The library will
							 * always call undo in the reverse order the item has been
							 * deleted. So you can insert the item at the position it
							 * was deleted from, unless you have modified the list
							 * (added or removed items) somewhere else in your activity.
							 * If you do so, you might want to call
							 * {@link SwipeDismissList#discardUndo()}, so the user
							 * cannot undo the action anymore. If you still want the
							 * user to be able to undo the deletion (after you modified
							 * the list somewhere else) you will need to calculate the
							 * new position of this item yourself.
							 */
							@Override
							public void undo() {
								// Reinsert the item at its previous position.
								listAdapter.insert(item, position);
								listView.setAdapter(listAdapter);
								listAdapter.notifyDataSetChanged();
							}

							/**
							 * Will be called, when the user doesn't have the
							 * possibility to undo the action anymore. This can either
							 * happen, because the undo timed out or
							 * {@link SwipeDismissList#discardUndo()} was called. If you
							 * have stored your objects somewhere persistent (e.g. a
							 * database) you might want to use this method to delete the
							 * object from this persistent storage.
							 */
							@Override
							public void discard() {
								if (useDiscardDefault)
									DatabaseUtil.excluirFavorito((Model)item);
								else
									discardActions((Model)item);
								extraDiscardActions();
							}
						};

					}
				},
				// 3rd parameter needs to be the mode the list is generated.
				mode);

		// If we have a MULTI_UNDO list (several items can be undone one by one),
		// set the UndoMultipleString to null. If you set this to null the undo popup
		// will show the title of the item that will be undone next. If you don't
		// set this to null (leave it default, or set some other string), the string
		// will be shown (and first placeholder %d replaced with number of pending undos).
		if (mode == SwipeDismissList.UndoMode.MULTI_UNDO) {
			mSwipeList.setUndoMultipleString(null);
		}
		mSwipeList.setAutoHideDelay(5000);
		mSwipeList.setRequireTouchBeforeDismiss(false);
	}
	
	public void extraDiscardActions() {}

	public void discardActions(Model item) {}
	
	@Override
	public boolean onPrepareActionMode(ActionMode mode, Menu menu) {
		return false;
	}

	@Override
	public boolean onActionItemClicked(ActionMode mode, MenuItem item) {
		return false;
	}
	
	@Override
	public boolean onCreateActionMode(ActionMode mode, Menu menu) {
		listAdapter.enterMultiMode();
		mActionMode = mode;
		return true;
	}

	@Override
	public void onDestroyActionMode(ActionMode mode) {
		listAdapter.exitMultiMode();
		mActionMode = null;
	}

	public int dp2px(int dp) {
		return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, dp, getResources().getDisplayMetrics());
	}
}
