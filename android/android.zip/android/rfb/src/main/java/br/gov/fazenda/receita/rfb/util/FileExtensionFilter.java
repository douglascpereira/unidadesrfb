package br.gov.fazenda.receita.rfb.util;

import java.io.File;
import java.io.FileFilter;

/**
 * Created by 03385437598 on 06/02/18.
 */

public class FileExtensionFilter implements FileFilter {

    public String[] extensions = new String[] { };

    public FileExtensionFilter(String... extensions) {
        this.extensions = extensions;
    }

    @Override
    public boolean accept(File file) {
        boolean isValid = false;
        if (file != null) {

            String name = file.getName().toLowerCase();
            for (String ext : extensions) {
                if ((name.endsWith(ext) || file.isDirectory()) && !file.getAbsolutePath().contains("cache") && !name.startsWith(".")) {
                    isValid = true;
                    break;
                }
            }
        }

        return isValid;
    }
}
