package br.gov.fazenda.receita.rfb.exception;

public class ParametrosInformadosNaoInformadosException extends RuntimeException {

	private static final long serialVersionUID = 1L;

}
