package br.gov.fazenda.receita.rfb.exception;

public class CNPJNaoInformadoException extends RuntimeException {

	private static final long serialVersionUID = 1L;

}
