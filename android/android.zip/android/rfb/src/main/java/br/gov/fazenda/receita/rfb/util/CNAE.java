package br.gov.fazenda.receita.rfb.util;

public class CNAE {
	public static String formatar(final String cnae) {
		String codigo = cnae;
		try {
			if(Long.valueOf(cnae) != null) {
				while(codigo.length() < 7)
					codigo = "0"+cnae;
				
				codigo = codigo.substring(0, 4)+"-"+codigo.substring(4,5)+"/"+codigo.substring(5,7);
			}
		} catch (NumberFormatException e) {
			// TODO: handle exception
		}
		return codigo;
	}
}
