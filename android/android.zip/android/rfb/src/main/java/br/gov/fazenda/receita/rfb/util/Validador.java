package br.gov.fazenda.receita.rfb.util;

import java.util.regex.Pattern;

/**
 * Validadores em geral.
 * 
 * @author SERPRO
 * @since 1.0.0
 */
final public class Validador {

	/**
	 * Constantes para uso com o metodo calculaModulo11
	 */
	public final static int MOD11_CASO_0 = 0;
	public final static int MOD11_CASO_1 = 1;
	public final static int MOD11_CASO_2 = 2;

	private Validador() {
	}

	/**
	 * Verificar se um CPF está formado corretamente.
	 * 
	 * @param cpf
	 *            CPF a ser verificado.
	 * @return
	 */
	public static boolean isCPFValido(final String cpf) {
		boolean result = false;
		char dig10, dig11;
		int sm, i, r, num, peso;

		try {
			sm = 0;
			peso = 10;

			for (i = 0; i < 9; i++) {
				num = (int) (cpf.charAt(i) - 48);
				sm = sm + (num * peso);
				peso = peso - 1;
			}

			r = 11 - (sm % 11);
			if ((r == 10) || (r == 11)) {
				dig10 = '0';
			} else {
				dig10 = (char) (r + 48);
			}
			sm = 0;
			peso = 11;

			for (i = 0; i < 10; i++) {
				num = (int) (cpf.charAt(i) - 48);
				sm = sm + (num * peso);
				peso = peso - 1;
			}

			r = 11 - (sm % 11);
			if ((r == 10) || (r == 11)) {
				dig11 = '0';
			} else {
				dig11 = (char) (r + 48);
			}

			if ((dig10 == cpf.charAt(9)) && (dig11 == cpf.charAt(10))) {
				result = true;
			}
		} catch (Throwable exception) {
			result = false;
		}
		return result;
	}

	/**
	 * Verificar se um CNPJ está formado corretamente.
	 * 
	 * @param cnpj
	 *            CNPJ a ser verificado.
	 * @return
	 */
	public static boolean isCNPJValido(final String cnpjStr) {
		boolean result = false;

		try {
			
			if (isStringVazia(cnpjStr)) {
				result = false;
			}
			
			if(cnpjStr.length() < 14) {
				result = false;
			}

	        int[] cnpj = converterArray(cnpjStr);
	        int[] v = new int[2];
	        
	        //Nota: Calcula o primeiro dígito de verificação.
	        v[0] = (5*cnpj[0]) + (4*cnpj[1]) + (3*cnpj[2]) + (2*cnpj[3]);
	        v[0] += (9*cnpj[4]) + (8*cnpj[5]) + (7*cnpj[6]) + (6*cnpj[7]);
	        v[0] += (5*cnpj[8]) + (4*cnpj[9]) + (3*cnpj[10]) + (2*cnpj[11]);
	        v[0] = 11 - (v[0] % 11);
	        v[0] = (v[0] >= 10) ? 0 : v[0];

	        //Nota: Calcula o segundo dígito de verificação.
	        v[1] = (6*cnpj[0]) + (5*cnpj[1]) + (4*cnpj[2]) + (3*cnpj[3]);
	        v[1] += (2*cnpj[4]) + (9*cnpj[5]) + (8*cnpj[6]) + (7*cnpj[7]);
	        v[1] += (6*cnpj[8]) + (5*cnpj[9]) + (4*cnpj[10]) + (3*cnpj[11]);
	        v[1] += (2 * cnpj[12]);
	        v[1] = 11 - (v[1] % 11);
	        v[1] = (v[1] >= 10) ? 0 : v[1];
	        
			//Nota: Verdadeiro se os dígitos de verificação são os esperados.
			if(v[0]!=cnpj[12] || v[1]!=cnpj[13]) {
				result = false;
			} else {
				result = true;
			}
		} catch (Throwable exception) {
			result = false;	
		}
		return result;
	}

	private static int[] converterArray(String cnpjStr) {
		int[] cnpj = new int[14];
		
		for(int i = 0; i<cnpj.length; i++) {
			if((cnpjStr.length() + i) < 14) {
				cnpj[i] = 0;
			} else {
				cnpj[i] = Integer.parseInt(cnpjStr.substring(i, i+1));
			}
		}
		
		return cnpj;
	}
	
	public static boolean isStringVazia(String s) {
		return (s == null || s.length() == 0);
	}

	public static boolean isEmailValido(String email) {
		Pattern p = Pattern.compile("[a-zA-Z0-9\\+\\.\\_\\%\\-\\+]{1,256}"
				+ "\\@" + "[a-zA-Z0-9][a-zA-Z0-9\\-]{0,64}" + "(" + "\\."
				+ "[a-zA-Z0-9][a-zA-Z0-9\\-]{0,25}" + ")+");

		return p.matcher(email).matches();
	}

	/**
	 * Calcula e retorna o modulo 11 do numerico em stEnt.
	 * @param stEnt Numerico do qual se deseja calcular o modulo 11.
	 * @param stMult String de multiplicacao desejada;
	 * se stMult == null, sera usado '... 12 11 10 98765432'.
	 * @param inStatus O modulo 11 consiste na diferenca entre 11 e o
	 * resto da divisao de um somatorio por 11. Para os valores de retorno 10
	 * (quanto o resto eh 1) ou 11 (resto 0), existem versoes com diferentes
	 * resultados; use as constantes MOD11_CASO_0, ..._1 e ..._2, conforme
	 * descrito abaixo, para especificar o retorno desejado para estas
	 * solucoes:<br>
	 * MOD11_CASO_0 : Usado no calculo de processos, retorna as saidas 10
	 * e 11 sem nenhum tratamento.<br>
	 * MOD11_CASO_1 : usado no calculo de processos com data superior a 2000
	 * e titulos de eleitor. Converte a saida 10 em 0 e saida 11 em 1.<br>
	 * MOD11_CASO_2 : usado no calculo do CNPJ e CPF, converte ambas saidas
	 * 10 e 11 em 0.
	 * @return int - O digito modulo 11 do numerico de entrada (entre 0 e 11).
	 *
	 * @author Ricardo Caetano
	 */
	public static int calcularModulo11(String stEnt, String stMult, int inStatus) {
		int inMod11, inResto, inSoma = 0;

		//Verifica se eh para usar stMult ou gerar um multiplicador padrao
		if (stMult == null) {
			// Gerar
			for (int i = 0; i < stEnt.length(); i++) {
				inSoma += ((stEnt.length() + 1 - i) * Character.getNumericValue(stEnt.charAt(i)));
			}
		}
		else {
			// Usar stMult
			for (int i = 0; i < stEnt.length(); i++) {
				inSoma += (Character.getNumericValue(stMult.charAt(i)) * Character.getNumericValue(stEnt.charAt(i)));
			}
		}

		// Faz o modulo 11 da soma obtida acima
		inResto = inSoma - ((inSoma / 11) * 11);

		// O resto pode variar de 0 a 11; Os restos 0 e 1 geram inMod11
		// igual a 11 ou 10 - valores problema que tem diferentes tratamentos
		// conforme inStatus.
		inMod11 = 11 - inResto;

		// Trata casos especiais
		if (inStatus == MOD11_CASO_2) {
			if (inMod11 > 9) {
				// Se o resto eh 1 ou 0 => inMod11 = 10 ou 11.
				// Para MOD11_CASO_2, retorna zero nos dois casos
				inMod11 = 0;
			}
		}
		else if (inStatus == MOD11_CASO_1) {
			if (inMod11 == 10) {
				// Se o resto eh 1 => inMod11 = 10.
				// Para MOD11_CASO_1, retorna zero
				inMod11 = 0;
			}
			if (inMod11 == 11) {
				// Se o resto eh 0 => inMod11 = 11.
				// Para MOD11_CASO_1, retorna um
				inMod11 = 1;
			}
		}

		// Para MOD11_CASO_0 o valor nao eh alterado
		return inMod11;
	}
}
