package br.gov.fazenda.receita.rfb.ui.activity;

import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

import java.io.File;

import br.gov.fazenda.receita.rfb.R;
import br.gov.fazenda.receita.rfb.ui.widget.TouchImageView;

public abstract class RFBViewActivity extends AppCompatActivity {

    protected Toolbar toolBar;

    protected TouchImageView imageView;

    protected String filePath = null;

    protected abstract Uri getUriFromFile(File file);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rfb_view);
        initToolBar();
        loadScreenObjects();
    }

    protected void initToolBar() {
        toolBar = (Toolbar) findViewById(R.id.myToolBar);
        setSupportActionBar(toolBar);
        toolBar.setNavigationIcon(R.drawable.abc_ic_ab_back_material); //R.drawable.abc_ic_ab_back_material
        toolBar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
    }

    protected void showImage() {
        if (filePath != null) {
            Drawable image = Drawable.createFromPath(filePath);
            imageView.setImageDrawable(image);
            imageView.requestFocusFromTouch();
            imageView.setMaxZoom(4);
        }
    }

    private void loadScreenObjects() {
        imageView = (TouchImageView) findViewById(R.id.rfb_imageview);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.rfb_compartilhar, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        super.onOptionsItemSelected(item);

        if (item.getItemId() == R.id.action_share) {
            File imagem = new File(filePath);
            Intent intent = new Intent(Intent.ACTION_SEND);
            intent.setType("image/png");
            intent.putExtra(Intent.EXTRA_STREAM, getUriFromFile(imagem));
            startActivity(Intent.createChooser(intent, getText(R.string.actionmenu_share_with)));
        }
        return true;
    }
}
