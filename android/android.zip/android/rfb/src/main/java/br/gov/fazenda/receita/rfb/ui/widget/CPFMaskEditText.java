package br.gov.fazenda.receita.rfb.ui.widget;

import android.content.Context;
import android.util.AttributeSet;
import br.gov.fazenda.receita.rfb.util.Mask;

public class CPFMaskEditText extends ExtendedEditText {

	public CPFMaskEditText(Context context) {
		super(context);
		maxLength = 14;
		initialize(context);
		editText.addTextChangedListener(Mask.insert("###.###.###-##", editText));
	}
	
	public CPFMaskEditText(final Context context, final AttributeSet attributeSet) {
		super(context, attributeSet);
		maxLength = 14;
		initialize(context);
		editText.addTextChangedListener(Mask.insert("###.###.###-##", editText));
	}
	
}
