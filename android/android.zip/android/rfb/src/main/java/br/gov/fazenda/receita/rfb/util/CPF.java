package br.gov.fazenda.receita.rfb.util;

final public class CPF {

	private CPF() {
		throw new AssertionError();
	}

	/**
	 * Obter um CPF qualquer e formatá-lo. Qualquer caracter diferente de
	 * números será ignorado. Portanto, um CPF do tipo 1111c11b11122a será
	 * formatado para 111.111.111-11
	 * 
	 * @param cpf Número do CPF.
	 * @return CPF formatado.
	 */
	public static String formatar(final String cpf) {
		if (cpf == null || "".equals(cpf)) {
			return "";
		}
		final String cpfSoNumeros = cpf.replaceAll("\\.", "").replaceAll("\\-", "");
		StringBuilder sb = new StringBuilder();
		sb.append(cpfSoNumeros.substring(0, 3));
		sb.append(".");
		sb.append(cpfSoNumeros.substring(3, 6));
		sb.append(".");
		sb.append(cpfSoNumeros.substring(6, 9));
		sb.append("-");
		sb.append(cpfSoNumeros.substring(9, 11));
		return sb.toString();
	}

}
