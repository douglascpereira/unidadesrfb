package br.gov.fazenda.receita.rfb.model;

import java.io.Serializable;
import java.util.Map;

public class JsonParam implements Serializable {

    private static final long serialVersionUID = 1L;

    public String idNuvem;
    public String aplicativo;
    public String so;
    public Map<String, String> parametros;
    public Boolean sandbox;
    public String badge;
    public String sound;
    public String mensagem;
    public Boolean silent;
    public Boolean fcm;

}
