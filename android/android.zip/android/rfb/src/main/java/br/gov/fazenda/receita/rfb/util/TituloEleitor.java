package br.gov.fazenda.receita.rfb.util;

final public class TituloEleitor {

	private TituloEleitor() {
	}

	public final static int MOD11_CASO_0 = 0;
	public final static int MOD11_CASO_1 = 1;
	public final static int MOD11_CASO_2 = 2;

	/**
	 * Valida a entrad em tituloEleitor como um numerico de um titulo de
	 * eleitor. Exemplo de um titulo valido: 0024585390248.<br>
	 * Formato geral do titulo : XXXXXXXXX UF DV, onde :<br>
	 * UF - digitos para a UF (01 a 28 - SP, MG, RJ, RS, BA, PR, CE, PE, SC, GO,
	 * MA, PB, PA, ES, PI, RN, AL, MT, MS, DF, SE, AM, RO, AC, AP, RR, TO,
	 * EXterior);<br>
	 * D -> digito verificador, dos 9 primeiros digitos (XXXXXXXXX) calculado em
	 * modulo 11, usando stMult == null => 10 98765432<br>
	 * V -> idem a D, para os digitos UFD, usando stMult == null => 432.<br>
	 * Se UF == 01 ou 02 - usar MOD11_CASO_1, senao ..._2.
	 * 
	 * @param tituloEleitor
	 *            string com o numerico a ser testado.
	 * @return null teste ok.
	 * @exception RetornoValidacao
	 *                se houve erro na validacao.
	 * @see Validador#calcularModulo11
	 * @see Validador#validarModulo11
	 * 
	 * @author Ricardo Caetano
	 */
	public static boolean validarTituloEleitor(String tituloEleitor) {
		int tamanho;
		int uf;
		int mod11;

		if (Strings.isEmpty(tituloEleitor)) {
			return false;
		}

		tituloEleitor = tituloEleitor.trim();
		tamanho = tituloEleitor.length();

		if (tamanho > 13 || tamanho < 3) {
			return false;
		}

		// Corrige a string de entrada, se necessario
		tituloEleitor = "0000000000000".substring(0, (13 - tamanho)) + tituloEleitor;

		// Testa se eh numerico
		if (!Strings.isNumeric(tituloEleitor)) {
			return false;
		}

		// Testa se o estado declarado no titulo eh valido
		uf = Integer.valueOf(tituloEleitor.substring(9, 11)).intValue();
		if ((uf < 1) || (uf > 28)) {
			return false;
		}

		// Se o estado for SP ou MG, use MOD11_CASO_1 em validarMod11
		if ((uf == 1) || (uf == 2)) {
			mod11 = MOD11_CASO_1;
		} else {
			mod11 = MOD11_CASO_2;
		}

		// Testa o DV
		if (!validarModulo11(tituloEleitor.substring(0, 9) + tituloEleitor.substring(11, 12), null, mod11)
				|| !validarModulo11(tituloEleitor.substring(9, 12) + tituloEleitor.substring(12, 13), null, mod11)) {
			return false;
		}

		return true;
	}

	/**
	 * Valida um numerico usando modulo 11. Considera que o ultimo caracter da
	 * string stEnt eh o DV a ser comparado com o valor calculado usando os
	 * demais caracteres da string. Isto eh, na string de entrada 71973524791
	 * (um CPF valido) o DV (1) eh comparado com o calculo em cima da strig
	 * 7197352479 (que dara 1) e retornara true.
	 * 
	 * @param stEnt
	 *            String que representa o numero a ser validado.
	 * @param stMult
	 *            String de multiplicacao desejada; se null, sera usado '... 12
	 *            11 10 98765432'.
	 * @param inStatus
	 *            O modulo 11 consiste na diferenca entre 11 e o resto da
	 *            divisao de um somatorio por 11. Para os valores de retorno 10
	 *            (quanto o resto eh 1) ou 11 (resto 0), existem versoes com
	 *            diferentes resultados; use as constantes MOD11_CASO_0, ..._1 e
	 *            ..._2, conforme descrito abaixo, para especificar o retorno
	 *            desejado para estas solucoes:<br>
	 *            MOD11_CASO_0 : Usado no calculo de processos, retorna as
	 *            saidas 10 e 11 sem nenhum tratamento.<br>
	 *            MOD11_CASO_1 : usado no calculo de processos com data superior
	 *            a 2000 e titulos de eleitor. Converte a saida 10 em 0 e saida
	 *            11 em 1.<br>
	 *            MOD11_CASO_2 : usado no calculo do CNPJ e CPF, converte ambas
	 *            saidas 10 e 11 em 0.
	 * @return boolean - true a string representa um modulo 11 valido.
	 * @see Validador#calcularModulo11
	 * 
	 * @author Ricardo Caetano
	 */
	private static boolean validarModulo11(String stEnt, String stMult, int inStatus) {
		String stDigVerif, stNumero;
		int inDigVerif, inDigVerifCalc;

		// Separa o numero para calcular o modulo 11
		stNumero = stEnt.substring(0, stEnt.length() - 1);
		inDigVerifCalc = calcularModulo11(stNumero, stMult, inStatus);

		// do digito verificador no proprio numero
		stDigVerif = stEnt.substring(stEnt.length() - 1, stEnt.length());
		inDigVerif = Integer.valueOf(stDigVerif).intValue();

		return (inDigVerifCalc == inDigVerif);
	}

	/**
	 * Calcula e retorna o modulo 11 do numerico em stEnt.
	 * 
	 * @param stEnt
	 *            Numerico do qual se deseja calcular o modulo 11.
	 * @param stMult
	 *            String de multiplicacao desejada; se stMult == null, sera
	 *            usado '... 12 11 10 98765432'.
	 * @param inStatus
	 *            O modulo 11 consiste na diferenca entre 11 e o resto da
	 *            divisao de um somatorio por 11. Para os valores de retorno 10
	 *            (quanto o resto eh 1) ou 11 (resto 0), existem versoes com
	 *            diferentes resultados; use as constantes MOD11_CASO_0, ..._1 e
	 *            ..._2, conforme descrito abaixo, para especificar o retorno
	 *            desejado para estas solucoes:<br>
	 *            MOD11_CASO_0 : Usado no calculo de processos, retorna as
	 *            saidas 10 e 11 sem nenhum tratamento.<br>
	 *            MOD11_CASO_1 : usado no calculo de processos com data superior
	 *            a 2000 e titulos de eleitor. Converte a saida 10 em 0 e saida
	 *            11 em 1.<br>
	 *            MOD11_CASO_2 : usado no calculo do CNPJ e CPF, converte ambas
	 *            saidas 10 e 11 em 0.
	 * @return int - O digito modulo 11 do numerico de entrada (entre 0 e 11).
	 * 
	 * @author Ricardo Caetano
	 */
	private static int calcularModulo11(String stEnt, String stMult, int inStatus) {
		int inMod11, inResto, inSoma = 0;

		// Verifica se eh para usar stMult ou gerar um multiplicador padrao
		if (stMult == null) {
			for (int i = 0; i < stEnt.length(); i++) {
				inSoma += ((stEnt.length() + 1 - i) * Character.getNumericValue(stEnt.charAt(i)));
			}
		} else {
			for (int i = 0; i < stEnt.length(); i++) {
				inSoma += (Character.getNumericValue(stMult.charAt(i)) * Character.getNumericValue(stEnt.charAt(i)));
			}
		}

		// Faz o modulo 11 da soma obtida acima
		inResto = inSoma - ((inSoma / 11) * 11);

		// O resto pode variar de 0 a 11; Os restos 0 e 1 geram inMod11 igual a
		// 11 ou 10 - valores problema que tem diferentes tratamentos conforme
		// inStatus.
		inMod11 = 11 - inResto;

		// Trata casos especiais
		if (inStatus == MOD11_CASO_2) {
			if (inMod11 > 9) {
				// Se o resto eh 1 ou 0 => inMod11 = 10 ou 11.
				// Para MOD11_CASO_2, retorna zero nos dois casos
				inMod11 = 0;
			}
		} else if (inStatus == MOD11_CASO_1) {
			if (inMod11 == 10) {
				// Se o resto eh 1 => inMod11 = 10.
				// Para MOD11_CASO_1, retorna zero
				inMod11 = 0;
			}
			if (inMod11 == 11) {
				// Se o resto eh 0 => inMod11 = 11.
				// Para MOD11_CASO_1, retorna um
				inMod11 = 1;
			}
		}

		// Para MOD11_CASO_0 o valor nao eh alterado
		return inMod11;
	}

}
