package br.gov.fazenda.receita.rfb.model;

/**
 * Códigos de Retorno do Serviço de Restituição.
 * 
 * @author SERPRO
 * @since 1.0.0
 */
public enum CodigoRetorno {

	OK("00"),
	ERRO_01("01"),
	ERRO_02("02"),
	ERRO_03("03"),
	ERRO_04("04"),
	ERRO_06("06"),
	ERRO_15("15"),
	ERRO_91("91"),
	ERRO_98("98"),
	ERRO_99("99"),
	ERRO_0002("0002"),
	ERRO_0003("0003"),
	ERRO_0004("0004"),
	ERRO_0005("0005"),
	ERRO_0101("0101"),
	ERRO_0102("0102"),
	ERRO_0901("0901"),
	ERRO_0902("0902"),
	ERRO_0903("0903"),
	ERRO_0904("0904"),
	ERRO_0908("0908"),
	ERRO_0999("0999");

	private String value;

	CodigoRetorno(final String value) {
		this.value = value;
	}

	@Override
	public String toString() {
		return value;
	}

	public String getValue() {
		return value;
	}

}
