package br.gov.fazenda.receita.rfb.ui.widget;

import java.util.HashMap;

import android.graphics.Bitmap;

public class Interrogacao {
	Bitmap _bitmap;
	Coordinates _coordinates;
    float x, y;
    float rotation;
    float speed;
    float rotationSpeed;
    int width, height;

    // This map stores pre-scaled bitmaps according to the width. No reason to create
    // new bitmaps for sizes we've already seen.
    static HashMap<Integer, Bitmap> bitmapMap = new HashMap<Integer, Bitmap>();
    
    public Interrogacao() {
		// TODO Auto-generated constructor stub
	}
    
	public Interrogacao(Bitmap bitmap) {
		_bitmap = bitmap;
		_coordinates = new Coordinates();
	}

	public Bitmap getGraphic() {
		return _bitmap;
	}

	public Coordinates getCoordinates() {
		return _coordinates;
	}

	public float getSpeed() {
		return speed;
	}

	public void setSpeed(int speed) {
		this.speed = speed;
	}

	/**
	 * Contains the coordinates of the graphic.
	 */
	public class Coordinates {
		private int _x = 100;
		private int _y = 0;

		public int getX() {
			return _x + _bitmap.getWidth() / 2;
		}

		public void setX(int value) {
			_x = value - _bitmap.getWidth() / 2;
		}

		public int getY() {
			return _y + _bitmap.getHeight() / 2;
		}

		public void setY(int value) {
			_y = value - _bitmap.getHeight() / 2;
		}

		public String toString() {
			return "Coordinates: (" + _x + "/" + _y + ")";
		}
	}
	
    static Interrogacao createInterrogacao(float xRange, Bitmap originalBitmap) {
    	Interrogacao interrogacao = new Interrogacao();
        // Size each interrogacao with a width between 5 and 55 and a proportional height
        interrogacao.width = (int)(5 + (float)Math.random() * 50);
        float hwRatio = originalBitmap.getHeight() / originalBitmap.getWidth();
        interrogacao.height = (int)(interrogacao.width * hwRatio);

        // Position the interrogacao horizontally between the left and right of the range
        interrogacao.x = (float)Math.random() * (xRange - interrogacao.width);
        // Position the interrogacao vertically slightly off the top of the display
        interrogacao.y = 0 - (interrogacao.height + (float)Math.random() * interrogacao.height);

        // Each interrogacao travels at 50-200 pixels per second
        interrogacao.speed = (float) Math.random() * 150;

        // Flakes start at -90 to 90 degrees rotation, and rotate between -45 and 45
        // degrees per second
        interrogacao.rotation = (float) Math.random() * 180 - 90;
        interrogacao.rotationSpeed = (float) Math.random() * 90 - 45;

        // Get the cached bitmap for this size if it exists, otherwise create and cache one
        interrogacao._bitmap = bitmapMap.get(interrogacao.width);
        if (interrogacao._bitmap == null) {
            interrogacao._bitmap = Bitmap.createScaledBitmap(originalBitmap,
                    (int)interrogacao.width, (int)interrogacao.height, true);
            bitmapMap.put(interrogacao.width, interrogacao._bitmap);
        }
        return interrogacao;
    }	
}
