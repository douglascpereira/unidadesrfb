package br.gov.fazenda.receita.rfb.util;

final public class CNPJ {

	private CNPJ() {
		throw new AssertionError();
	}

	/**
	 * Obter um CNPJ qualquer e formatá-lo. Qualquer caracter diferente de
	 * números será ignorado.
	 * 
	 * @param cnpj Número do CNPJ.
	 * @return CNPJ formatado.
	 */
	public static String formatar(final String cnpj) {
		if (cnpj == null || "".equals(cnpj)) {
			return "";
		}
		
		final String cnpjSoNumeros = cnpj.replaceAll("(\\.|-|_|/)", "");
		StringBuilder lCnpjFormatado = new StringBuilder();

            lCnpjFormatado.append(cnpjSoNumeros, 0, 2);
            lCnpjFormatado.append(".");
            lCnpjFormatado.append(cnpjSoNumeros, 2, 5);
            lCnpjFormatado.append(".");
            lCnpjFormatado.append(cnpjSoNumeros, 5, 8);
            lCnpjFormatado.append("/");
            lCnpjFormatado.append(cnpjSoNumeros, 8, 12);
            lCnpjFormatado.append("-");
            lCnpjFormatado.append(cnpjSoNumeros, 12, cnpjSoNumeros.length());

        return lCnpjFormatado.toString();
	}

}
