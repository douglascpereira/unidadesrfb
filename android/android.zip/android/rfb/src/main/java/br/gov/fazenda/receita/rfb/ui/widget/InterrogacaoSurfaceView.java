package br.gov.fazenda.receita.rfb.ui.widget;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.PixelFormat;
import android.util.AttributeSet;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import br.gov.fazenda.receita.rfb.R;
import br.gov.fazenda.receita.rfb.ui.widget.Interrogacao.Coordinates;

public class InterrogacaoSurfaceView extends SurfaceView implements SurfaceHolder.Callback {
	private SurfaceHolder holder;
	private AnimThread animThread;
	private final List<Interrogacao> interrogacaos = new ArrayList<Interrogacao>();
	private int height;
	private Bitmap back;

	public InterrogacaoSurfaceView(final Context context, AttributeSet attrs) {
		super(context, attrs);
		holder = getHolder();
		holder.addCallback(this);
		this.back = BitmapFactory.decodeResource(getResources(), R.color.background_white);
		holder.setFormat(PixelFormat.TRANSPARENT);
	}

	@Override
	protected void onDraw(final Canvas canvas) {
		if (canvas != null) {
			canvas.drawBitmap(back, 0, 0, null);
			for (int i = 0; i < interrogacaos.size(); i++) {
				final Interrogacao interrogacao = interrogacaos.get(i);
				final Bitmap bitmap = interrogacao.getGraphic();
				final Coordinates coords = interrogacao.getCoordinates();
				canvas.drawBitmap(bitmap, coords.getX(), coords.getY() - interrogacao.getSpeed(), null);
				coords.setY(coords.getY() + 1);

				if ((coords.getY() - interrogacao.getSpeed()) > this.height) {
					coords.setY(0);
				}
			}
		}
	}

	@Override
	public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {
		this.height = height;
		final int interrogacaoFlakeCount = Math.max(width, height) / 20;
		final Random random = new Random();
		interrogacaos.clear();
		for (int quantity = 0; quantity < interrogacaoFlakeCount; quantity++) {
			final Interrogacao interrogacao = new Interrogacao((BitmapFactory.decodeResource(getResources(), R.drawable.interrogacao2)));
			interrogacao.getCoordinates().setX(random.nextInt(width - 30));
			interrogacao.getCoordinates().setY(0);
			interrogacao.setSpeed(random.nextInt(2500));
			interrogacaos.add(interrogacao);
		}
	}

	@Override
	public void surfaceCreated(SurfaceHolder holder) {
		animThread = new AnimThread(holder, this);
		animThread.setRunning(true);
		animThread.start();
	}

	@Override
	public void surfaceDestroyed(SurfaceHolder holder) {
		boolean retry = true;
		animThread.setRunning(false);
		while (retry) {
			try {
				animThread.join();
				retry = false;
			} catch (InterruptedException e) {
			}
		}
	}
}