package br.gov.fazenda.receita.rfb.util;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;

/**
 * Utilitário para obter informações da Internet.
 * 
 * @author SERPRO
 * @since 1.0.0
 */
final public class HttpUtil {

	/**
	 * Checar se o dispositivo está conectado à internet.
	 * 
	 * @param context Contexto.
	 * @return Verdadeiro caso esteja conectado, falso caso não estjea.
	 */
	public static boolean isOnline(final Context context) {
		boolean result = false;
		ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
		NetworkInfo netInfo = cm.getActiveNetworkInfo();
		if (netInfo != null && netInfo.isConnectedOrConnecting()) {
			result = true;
		}
		return result;
	}
}
