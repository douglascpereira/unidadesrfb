package br.gov.fazenda.receita.rfb.util;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteQueryBuilder;
import android.os.Bundle;
import android.util.Log;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;

public class DBHelper extends SQLiteOpenHelper {

//    private static final int DATABASE_VERSION = 1;
//	private static final String TAG = DBHelper.class.getSimpleName();
	private static DBHelper instance;
	private static String dbName;
    private static int dbVersion;
	
    public DBHelper(Context context) {
        super(context, dbName, null, dbVersion);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
    }

	@Override
	public void onUpgrade(SQLiteDatabase db, int oldVersoin, int newVersion) {
	}
	
	public static DBHelper getInstance(Context context){
		if(instance == null) {
	        ApplicationInfo ai;
			try {
				ai = context.getPackageManager().getApplicationInfo(context.getPackageName(), PackageManager.GET_META_DATA);
		        Bundle bundle = ai.metaData;
		        dbName = bundle.getString("DATABASE_NAME");
                dbVersion = bundle.getInt("DATABASE_VERSION");
            } catch (NameNotFoundException e) {
				dbName = "database.sqlite";
			}
			instance = new DBHelper(context);
		}
		
		return instance;
	}

	public static SQLiteDatabase getReadableDatabase(Context context) {
		return getInstance(context).getReadableDatabase();
	}

	public static <T>  List<T> executeQuery(Context context, String tables, String[] columns,
                                                           String where, String[] params, String groupBy, String having, String orderBy,
                                                           String limit, Boolean distinct, Class<T> clazz) throws IllegalAccessException, InstantiationException, NoSuchFieldException {
        SQLiteQueryBuilder builder = new SQLiteQueryBuilder();
        builder.setTables(tables);
        builder.setDistinct(distinct);
        Cursor cursor = builder.query(getInstance(context).getReadableDatabase(), columns, where, params, groupBy, having, orderBy, limit);
        String[] colunas = cursor.getColumnNames();

        List<T> list = new ArrayList();

        while (cursor.moveToNext()){
            Object obj = clazz.newInstance();
            Class objClass = obj.getClass();
            for(int i =0; i < colunas.length; i++){
                int index = cursor.getColumnIndex(colunas[i]);
                Field field = objClass.getDeclaredField(colunas[i]);
                int fieldType = cursor.getType(index);
                if (fieldType == Cursor.FIELD_TYPE_INTEGER) {
                    field.setInt(obj, cursor.getInt(index));
                } else if (fieldType == Cursor.FIELD_TYPE_BLOB) {
                    field.set (obj, cursor.getBlob(index));
                } else if (fieldType == Cursor.FIELD_TYPE_FLOAT) {
                    field.setFloat(obj, cursor.getFloat(index));
                } else if (fieldType == Cursor.FIELD_TYPE_STRING) {
                    field.set(obj, cursor.getString(index));
                } else if (fieldType == Cursor.FIELD_TYPE_NULL) {
                    field.set(obj, null);
                }
            }
            list.add((T)obj);
        }

        cursor.close();
        return list;
	}


	public static SQLiteDatabase getWritableDatabase(Context context){
		return getInstance(context).getWritableDatabase();
	}
}
