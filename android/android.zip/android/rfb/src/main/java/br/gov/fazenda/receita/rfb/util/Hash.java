package br.gov.fazenda.receita.rfb.util;

import java.io.UnsupportedEncodingException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.Mac;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;

import org.apache.commons.codec.binary.Hex;

/**
 * Classe utilitária para geração de Hash
 */
public class Hash {

	// algoritimo ofuscado para dificultar engenharia reversa
	// o algoritimo é HmacSHA1
	private static final String ALGORITIMO_HASH = new ObfuscatedString(
			new long[] { 0xCC38595C2EAC160DL, 0x6617344F7585217CL }).toString();

	/**
	 * Gera um hash usando algoritmo HMACSha1.
	 * 
	 * @param text
	 *            texto a ser utilizado na geração do hash;
	 * @param key
	 *            chave a ser utilizada na geração do hash;
	 * @return hash gerado;
	 * @since 1.0
	 */
	public static String generateHash(String key, String text) {
		SecretKeySpec keySpec = new SecretKeySpec(key.getBytes(),
				ALGORITIMO_HASH);

		try {
			Mac mac = Mac.getInstance(ALGORITIMO_HASH);
			mac.init(keySpec);
			byte[] rawMac = mac.doFinal(text.getBytes("UTF-8"));
			byte[] hexBytes = new Hex().encode(rawMac);
			return new String(hexBytes, "ISO-8859-1");
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		} catch (InvalidKeyException e) {
			e.printStackTrace();
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}

		return null;
	}

	public static boolean validateHash(String key, String text,
			String expectedHash) {
		String hash = generateHash(key, text);
		return (expectedHash.equals(hash));
	}

	public static byte[] keyGen(String key, String algoritmo, String secure)
			throws NoSuchAlgorithmException {
		byte[] keyStart = key.getBytes();
		KeyGenerator kgen = KeyGenerator.getInstance(algoritmo);
		SecureRandom sr = SecureRandom.getInstance(secure);
		sr.setSeed(keyStart);
		kgen.init(128, sr); // 192 and 256 bits may not be available
		SecretKey skey = kgen.generateKey();
		return skey.getEncoded();
	}

	public static byte[] encrypt(byte[] raw, byte[] clear, String algoritmo)
			throws Exception {
		SecretKeySpec skeySpec = new SecretKeySpec(raw, algoritmo);
		Cipher cipher = Cipher.getInstance(algoritmo);
		cipher.init(Cipher.ENCRYPT_MODE, skeySpec);
		byte[] encrypted = cipher.doFinal(clear);
		return encrypted;
	}

	public static byte[] decrypt(byte[] raw, byte[] encrypted, String algoritmo)
			throws Exception {
		SecretKeySpec skeySpec = new SecretKeySpec(raw, algoritmo);
		Cipher cipher = Cipher.getInstance(algoritmo);
		cipher.init(Cipher.DECRYPT_MODE, skeySpec);
		byte[] decrypted = cipher.doFinal(encrypted);
		return decrypted;
	}
}
