package br.gov.fazenda.receita.rfb.util;

import androidx.core.content.FileProvider;

public class GenericFileProvider extends FileProvider {

}