package br.gov.fazenda.receita.rfb.util;

import android.content.res.AssetManager;
import android.graphics.Typeface;
import android.widget.TextView;

/**
 * Utilitário para mudar fontes de componentes.
 * 
 * @author SERPRO
 * @since 1.0.0
 */
final public class FontUtil {

	private FontUtil() {
	}

	public static void setLatoRegular(final TextView textView, final AssetManager assetManager) {
		Typeface typeface = Typeface.createFromAsset(assetManager, "fonts/latoregular.ttf");
		textView.setTypeface(typeface);
	}

	public static void setLatoBold(final TextView textView, final AssetManager assetManager) {
		Typeface typeface = Typeface.createFromAsset(assetManager, "fonts/latobold.ttf");
		textView.setTypeface(typeface);
	}

	public static Typeface getLatoRegular(final AssetManager assetManager) {
		return Typeface.createFromAsset(assetManager, "fonts/latoregular.ttf");
	}

}
