package br.gov.fazenda.receita.rfb.ui.widget;

import android.content.Context;
import android.graphics.Typeface;
import android.util.AttributeSet;

import androidx.appcompat.widget.AppCompatTextView;

public class LatoTextView extends AppCompatTextView {
	int style;
	AttributeSet attrs;
	public LatoTextView(Context context, AttributeSet attrs, int defStyle) {
		super(context, attrs, defStyle);
		this.style = defStyle;
		this.attrs = attrs;
		init();
	}

	public LatoTextView(Context context, AttributeSet attrs) {
		super(context, attrs);
		this.attrs = attrs;
		init();
	}

	public LatoTextView(Context context) {
		super(context);
		init();
	}

	private void init() {
		if (!isInEditMode()) {
			Typeface tf = null;
			
			for(int i=0; i< attrs.getAttributeCount(); i++){
				if(attrs.getAttributeName(i).equalsIgnoreCase("textStyle") && attrs.getAttributeIntValue(i, 0) == 1) {
					tf = Typeface.createFromAsset(getContext().getAssets(),	"fonts/latobold.ttf");
					break;
				}
			}
			
			if(tf == null)
				tf = Typeface.createFromAsset(getContext().getAssets(),	"fonts/latoregular.ttf");
			setTypeface(tf);
		}
	}
}
