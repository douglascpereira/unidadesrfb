package br.gov.fazenda.receita.rfb.util;

import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.Bitmap.Config;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.PorterDuff.Mode;
import android.graphics.PorterDuffXfermode;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import android.media.ExifInterface;
import android.net.Uri;
import android.os.Environment;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListAdapter;
import android.widget.ListView;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import br.gov.fazenda.receita.rfb.BuildConfig;
import br.gov.fazenda.receita.rfb.R;

public class ImageUtil {

	public static final String TAG = ImageUtil.class.getSimpleName();

    public static final int MEDIA_TYPE_IMAGE = 1;
    public static final int MEDIA_TYPE_VIDEO = 2;
	
	/** Create a File for saving an image or video */
	public static File getOutputMediaFile(int type, String dir, String nomeArquivo){
	    // To be safe, you should check that the SDCard is mounted
	    // using Environment.getExternalStorageState() before doing this.

	    File mediaStorageDir = new File(Environment.getExternalStoragePublicDirectory(
	              Environment.DIRECTORY_PICTURES), dir);
	    // This location works best if you want the created images to be shared
	    // between applications and persist after your app has been uninstalled.

	    // Create the storage directory if it does not exist
	    if (! mediaStorageDir.exists()){
	        if (! mediaStorageDir.mkdirs()){
	            Log.d(dir, "failed to create directory");
	            return null;
	        }
	    }

	    File mediaFile;
	    if (type == MEDIA_TYPE_IMAGE){
	        mediaFile = new File(mediaStorageDir.getPath() + File.separator + nomeArquivo);
	    } else if(type == MEDIA_TYPE_VIDEO) {
	        mediaFile = new File(mediaStorageDir.getPath() + File.separator + nomeArquivo);
	    } else {
	        return null;
	    }

	    return mediaFile;
	}
	
	public static void adicionarNaGaleria(Context context, Uri uri) {
		Intent intent = new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE);
		intent.setData(uri);
		context.sendBroadcast(intent);
	}
	
	public static int calculateInSampleSize(BitmapFactory.Options options,
			int reqWidth, int reqHeight) {
		// Raw height and width of image
		final int height = options.outHeight;
		final int width = options.outWidth;
		int inSampleSize = 1;

		if (height > reqHeight || width > reqWidth) {

			final int halfHeight = height / 2;
			final int halfWidth = width / 2;

			// Calculate the largest inSampleSize value that is a power of 2 and
			// keeps both height and width larger than the requested height and width.
			while ((halfHeight / inSampleSize) > reqHeight
					&& (halfWidth / inSampleSize) > reqWidth) {
				inSampleSize *= 2;
			}
		}

		return inSampleSize;
	}

	public static Bitmap decodeSampledBitmapFromStream(InputStream is,
			int resId, int reqWidth, int reqHeight) {

		// First decode with inJustDecodeBounds=true to check dimensions
		final BitmapFactory.Options options = new BitmapFactory.Options();
		options.inJustDecodeBounds = true;
		BitmapFactory.decodeStream(is, null, options);

		// Calculate inSampleSize
		options.inSampleSize = calculateInSampleSize(options, reqWidth,
				reqHeight);

		// Decode bitmap with inSampleSize set
		options.inJustDecodeBounds = false;
		return BitmapFactory.decodeStream(is, null, options);
	}

	public static Bitmap decodeSampledBitmapFromResource(Resources res,
			int resId, int reqWidth, int reqHeight) {

		// First decode with inJustDecodeBounds=true to check dimensions
		final BitmapFactory.Options options = new BitmapFactory.Options();
		options.inJustDecodeBounds = true;
		BitmapFactory.decodeResource(res, resId, options);

		// Calculate inSampleSize
		options.inSampleSize = calculateInSampleSize(options, reqWidth,
				reqHeight);

		// Decode bitmap with inSampleSize set
		options.inJustDecodeBounds = false;
		return BitmapFactory.decodeResource(res, resId, options);
	}

	public static Bitmap loadBitmap(Context context, Uri fileUri) {
		ContentResolver cr = context.getContentResolver();
		InputStream in = null;
		try {
        	in = cr.openInputStream(fileUri);
		} catch (FileNotFoundException e) {
			if (BuildConfig.DEBUG) e.printStackTrace();
		}
		
		BitmapFactory.Options options = new BitmapFactory.Options();
		options.inSampleSize = 5;
		Bitmap bitmap = BitmapFactory.decodeStream(in, null, options);

		Bitmap adjustedBitmap = null;
		try {
			adjustedBitmap = modifyOrientation(bitmap, CameraUtil.getPath(context, fileUri));
		} catch (Exception e) {
			if (BuildConfig.DEBUG) e.printStackTrace();
		}

		return adjustedBitmap;
	}
	
	private static int exifToDegrees(int exifOrientation) {
		if (exifOrientation == ExifInterface.ORIENTATION_ROTATE_90) {
			return 90;
		} else if (exifOrientation == ExifInterface.ORIENTATION_ROTATE_180) {
			return 180;
		} else if (exifOrientation == ExifInterface.ORIENTATION_ROTATE_270) {
			return 270;
		}
		return 0;
	}

	public static Bitmap modifyOrientation(Bitmap bitmap, String image_absolute_path) throws IOException {
		ExifInterface ei = new ExifInterface(image_absolute_path);
		int orientation = ei.getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL);

		switch (orientation) {
			case ExifInterface.ORIENTATION_ROTATE_90:
				return rotate(bitmap, 90);

			case ExifInterface.ORIENTATION_ROTATE_180:
				return rotate(bitmap, 180);

			case ExifInterface.ORIENTATION_ROTATE_270:
				return rotate(bitmap, 270);

			case ExifInterface.ORIENTATION_FLIP_HORIZONTAL:
				return flip(bitmap, true, false);

			case ExifInterface.ORIENTATION_FLIP_VERTICAL:
				return flip(bitmap, false, true);

			default:
				return bitmap;
		}
	}

	public static Bitmap rotate(Bitmap bitmap, float degrees) {
		Matrix matrix = new Matrix();
		matrix.postRotate(degrees);
		return Bitmap.createBitmap(bitmap, 0, 0, bitmap.getWidth(), bitmap.getHeight(), matrix, true);
	}

	public static Bitmap flip(Bitmap bitmap, boolean horizontal, boolean vertical) {
		Matrix matrix = new Matrix();
		matrix.preScale(horizontal ? -1 : 1, vertical ? -1 : 1);
		return Bitmap.createBitmap(bitmap, 0, 0, bitmap.getWidth(), bitmap.getHeight(), matrix, true);
	}

	public static Bitmap getCircleBitmap(Bitmap bitmap) {
		if (bitmap == null)
			return null;

		Bitmap circleBitmap = Bitmap.createBitmap(bitmap.getWidth(), bitmap.getHeight(), Bitmap.Config.ARGB_8888);

		Canvas c = new Canvas(circleBitmap);
		Paint paint = new Paint();
		Rect rect = new Rect(0, 0, bitmap.getWidth(), bitmap.getHeight());

		paint.setAntiAlias(true);
		c.drawARGB(0, 0, 0, 0);
		paint.setColor(Color.WHITE);

		float radius = (bitmap.getWidth() > bitmap.getHeight()) ? bitmap.getHeight() / 2 : bitmap.getWidth() / 2;

		c.drawCircle(bitmap.getWidth() / 2, bitmap.getHeight() / 2,	radius, paint);
		paint.setXfermode(new PorterDuffXfermode(Mode.SRC_IN));
		c.drawBitmap(bitmap, rect, rect, paint);

		return circleBitmap;
	}

	public static Bitmap getRoundedCornerBitmap(Bitmap bitmap, int pixels) {
		Bitmap output = Bitmap.createBitmap(bitmap.getWidth(),
				bitmap.getHeight(), Config.ARGB_8888);
		Canvas canvas = new Canvas(output);

		final Paint paint = new Paint();
		final Rect rect = new Rect(0, 0, bitmap.getWidth(), bitmap.getHeight());
		final RectF rectF = new RectF(rect);
		final float roundPx = pixels;

		paint.setAntiAlias(true);
		canvas.drawARGB(0, 0, 0, 0);
		paint.setColor(Color.WHITE);
		canvas.drawRoundRect(rectF, roundPx, roundPx, paint);

		paint.setXfermode(new PorterDuffXfermode(Mode.SRC_IN));
		canvas.drawBitmap(bitmap, rect, rect, paint);

		return output;
	}

	public static File gerarImagemParaCompatilhamento(ViewGroup view) {
		return gerarImagemParaCompatilhamento(view, true, null);
	}

	public static File gerarImagemParaCompatilhamento(ViewGroup view, boolean haveChild) {
		return gerarImagemParaCompatilhamento(view, haveChild, null);
	}

	public static File gerarImagemParaCompatilhamento(ViewGroup view, boolean haveChild, ViewGroup viewCabecalho) {
		View v = new View(view.getContext());
		v.setDrawingCacheEnabled(true);
		v.buildDrawingCache(true);

		View viewToolBar = view.getRootView().findViewWithTag("myToolBar");
		Bitmap bitmapToolBar = getBitmapFromView(viewToolBar, viewToolBar.getHeight());

		Bitmap bitmap;
		if (view instanceof ListView) {
			bitmap = getBitmapFromListView((ListView) view);
		} else {
			int height = (haveChild) ? view.getChildAt(0).getHeight() * view.getChildCount() : view.getHeight();
			if (height <= 0) {
				return null;
			}
			bitmap = getBitmapFromView(view, height);
		}

		int height = bitmapToolBar.getHeight() + bitmap.getHeight();
		Bitmap bitmapCabecalho = null;
		if (viewCabecalho != null) {
			bitmapCabecalho = getBitmapFromView(viewCabecalho, viewCabecalho.getHeight());
			height += bitmapCabecalho.getHeight();
		}
		Bitmap bitmapFinal = Bitmap.createBitmap(bitmapToolBar.getWidth(), height, Bitmap.Config.RGB_565);

		Canvas canvas = new Canvas(bitmapFinal);
		v.layout(0, 0, bitmapToolBar.getWidth(), height);
		v.setBackgroundResource(R.color.background_white);
		v.draw(canvas);

		canvas.drawBitmap(bitmapToolBar, 0, 0, new Paint());
		if (bitmapCabecalho != null) {
			canvas.drawBitmap(bitmapCabecalho, 0, bitmapToolBar.getHeight(), new Paint());
			canvas.drawBitmap(bitmap, 0, bitmapToolBar.getHeight() + bitmapCabecalho.getHeight(), new Paint());
		} else {
			canvas.drawBitmap(bitmap, 0, bitmapToolBar.getHeight(), new Paint());
		}

		ByteArrayOutputStream bytes = new ByteArrayOutputStream();
		bitmapFinal.compress(Bitmap.CompressFormat.PNG, 100, bytes);
		File file = new File(view.getContext().getExternalCacheDir() + File.separator + "share.png");
		try {
			file.createNewFile();
			FileOutputStream fileOutput = new FileOutputStream(file);
			fileOutput.write(bytes.toByteArray());
			fileOutput.close();
		} catch (IOException e) {
			if (BuildConfig.DEBUG) e.printStackTrace();
			return null;
		}
		v.setDrawingCacheEnabled(false);
		return file;
	}

	public static Bitmap getBitmapFromListView(ListView listView) {

		ListAdapter adapter  = listView.getAdapter();
		int itemscount       = adapter.getCount();
		int allitemsheight   = 0;
		List<Bitmap> bmps    = new ArrayList<Bitmap>();

		for (int i = 0; i < itemscount; i++) {

			View childView      = adapter.getView(i, null, listView);
			childView.measure(View.MeasureSpec.makeMeasureSpec(listView.getWidth(), View.MeasureSpec.EXACTLY),
					View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED));

			childView.layout(0, 0, childView.getMeasuredWidth(), childView.getMeasuredHeight());
			childView.setDrawingCacheEnabled(true);
			childView.buildDrawingCache();
			bmps.add(childView.getDrawingCache());
			allitemsheight+=childView.getMeasuredHeight();
		}

		Bitmap bigbitmap    = Bitmap.createBitmap(listView.getMeasuredWidth(), allitemsheight, Bitmap.Config.ARGB_8888);
		Canvas bigcanvas    = new Canvas(bigbitmap);

		Paint paint = new Paint();
		int iHeight = 0;

		for (int i = 0; i < bmps.size(); i++) {
			Bitmap bmp = bmps.get(i);
			bigcanvas.drawBitmap(bmp, 0, iHeight, paint);
			iHeight+=bmp.getHeight();

			bmp.recycle();
			bmp=null;
		}

		return bigbitmap;
	}

	public static Bitmap getBitmapFromView(View view, int height) {
		//Define a bitmap with the same size as the view
		Bitmap returnedBitmap = Bitmap.createBitmap(view.getWidth(), height, Bitmap.Config.ARGB_8888);
		//Bind a canvas to it
		Canvas canvas = new Canvas(returnedBitmap);
		//Get the view's background
		Drawable bgDrawable = view.getBackground();
		if (bgDrawable!=null)
			//has background drawable, then draw it on the canvas
			bgDrawable.draw(canvas);
		// draw the view on the canvas
		view.draw(canvas);
		//return the bitmap
		return returnedBitmap;
	}
}
