package br.gov.fazenda.receita.rfb.exception;

public class ErroGenericoServidorException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public ErroGenericoServidorException() {
		super();
	}

	public ErroGenericoServidorException(String detailMessage, Throwable throwable) {
		super(detailMessage, throwable);
	}

	public ErroGenericoServidorException(String detailMessage) {
		super(detailMessage);
	}

	public ErroGenericoServidorException(Throwable throwable) {
		super(throwable);
	}

}
