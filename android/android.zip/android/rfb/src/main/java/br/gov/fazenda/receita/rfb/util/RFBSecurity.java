package br.gov.fazenda.receita.rfb.util;

import android.app.Activity;
import android.app.AlertDialog;
import android.net.Uri;
import android.os.Build;

import br.gov.fazenda.receita.rfb.R;

public class RFBSecurity {

    public static void verificarAcessoIndevido(Activity activity) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP_MR1) {
            Uri referrer = activity.getReferrer();
            if (referrer != null && referrer.getAuthority() != null
                    && !referrer.getAuthority().startsWith("br.gov.fazenda.receita")) {

                showMessage(activity, R.string.mensagem_acesso_bloqueado);
            }
        }
    }

    public static void bloquearEmuladorProblematico(Activity activity) {
        if (Build.MODEL.equalsIgnoreCase("Full Android on Emulator")
                && Build.VERSION.RELEASE.equals("4.1.1")) {

            showMessage(activity, R.string.mensagem_emulador_acesso_bloqueado);
        }
    }

    private static void showMessage(Activity activity, int message) {
        AlertDialog.Builder builder = new AlertDialog.Builder(activity);
        builder.setMessage(activity.getString(message));
        builder.setTitle(activity.getString(R.string.alertDialogAvisoTitle));
        builder.setPositiveButton(activity.getString(R.string.alertDialogButtonPositive), (dialog, which) -> activity.finishAffinity());
        builder.create().show();
    }
}
