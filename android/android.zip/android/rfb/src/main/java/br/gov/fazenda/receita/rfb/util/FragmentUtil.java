package br.gov.fazenda.receita.rfb.util;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

public class FragmentUtil {
	
	private Fragment fragment;
	private FragmentManager manager;
	private int flagAnimation;
	private int enterAnimation;
	private int exitAnimation;
	private int popEnterAnimation;
	private int popExitAnimation;
	public int transitionAnimation = 0;
	
	public FragmentUtil(FragmentManager manager) {
		this.manager = manager;
	}
	
	public FragmentUtil(FragmentManager manager, Fragment fragment) {
		this.manager = manager;
		this.fragment = fragment;
	}
	
	public void setAnimation(int enter, int exit) {
		this.enterAnimation = enter;
		this.exitAnimation = exit;
		this.flagAnimation = 1;
	}
	
	public void setAnimation(int enter, int exit, int popEnter, int popExit) {
		this.enterAnimation = enter;
		this.exitAnimation = exit;
		this.popEnterAnimation = popEnter;
		this.popExitAnimation = popExit;
		this.flagAnimation = 2;
	}
	
	public void show() {
		FragmentTransaction transaction = manager.beginTransaction();
		if (flagAnimation == 1) {
			transaction.setCustomAnimations(enterAnimation, exitAnimation);
		} else if (flagAnimation == 2) {
			transaction.setCustomAnimations(enterAnimation, exitAnimation, popEnterAnimation, popExitAnimation);
		}
		if (transitionAnimation != 0) {
			transaction.setTransition(transitionAnimation);
		}
		transaction.show(fragment).commit();
	}
	
	public void show(Integer idFragment, boolean animation) {
		FragmentTransaction transaction = manager.beginTransaction();
		if (animation) {
			transaction.setCustomAnimations(android.R.anim.fade_in, android.R.anim.fade_out);
			transaction.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_FADE);
		}
		transaction.show(manager.findFragmentById(idFragment)).commit();
	}
	
	public void show(boolean animation) {
		FragmentTransaction transaction = manager.beginTransaction();
		if (animation) {
			transaction.setCustomAnimations(android.R.anim.fade_in, android.R.anim.fade_out);
			transaction.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_FADE);
		}
		transaction.show(fragment).commit();
	}
	
	public void replace(Fragment fragment, int content_frame, boolean animation) {
		FragmentTransaction transaction = manager.beginTransaction();
		if (animation) {
			transaction.setCustomAnimations(android.R.anim.fade_in, android.R.anim.fade_out);
			transaction.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_FADE);
		}
		transaction.replace(content_frame, fragment);
		transaction.commit();
	}	
	
	public void hide() {
		FragmentTransaction transaction = manager.beginTransaction();
		if (flagAnimation == 1) {
			transaction.setCustomAnimations(enterAnimation, exitAnimation);
		} else if (flagAnimation == 2) {
			transaction.setCustomAnimations(enterAnimation, exitAnimation, popEnterAnimation, popExitAnimation);
		}
		if (transitionAnimation != 0) {
			transaction.setTransition(transitionAnimation);
		}
		transaction.hide(fragment).commit();
	}
	
	public void hide(boolean animation) {
		FragmentTransaction transaction = manager.beginTransaction();
		if (animation) {
			transaction.setTransition(FragmentTransaction.TRANSIT_UNSET);
		}
		transaction.hide(fragment).commit();
	}
	
	public void hide(Integer idFragment, boolean animation) {
		FragmentTransaction transaction = manager.beginTransaction();
		if (animation) {
			transaction.setCustomAnimations(android.R.anim.fade_in, android.R.anim.fade_out);
			transaction.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_FADE);
		}
		transaction.hide(manager.findFragmentById(idFragment)).commit();
	}
}
