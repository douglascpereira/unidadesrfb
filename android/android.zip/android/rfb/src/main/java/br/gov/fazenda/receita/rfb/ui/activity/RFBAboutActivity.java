package br.gov.fazenda.receita.rfb.ui.activity;

import android.app.Activity;
import android.os.Bundle;
import androidx.annotation.Nullable;
import android.text.SpannableString;
import android.text.style.UnderlineSpan;
import android.view.View;
import android.view.Window;
import android.widget.ImageView;
import android.widget.TextView;

import br.gov.fazenda.receita.rfb.R;

public abstract class RFBAboutActivity extends Activity {

    private ImageView appIcon;
    private TextView appName;
    private TextView appVersion;
    private TextView androidVersion;
    private TextView rfbLink;

    protected int icon = 0;
    protected String name = null;
    protected String version = null;
    protected String versionSO = null;

    public abstract void openLink(String url);

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.layout_sobre);

        loadScreenObjects();
    }

    private void loadScreenObjects() {
        appIcon = (ImageView) findViewById(R.id.imageView_appIcon);
        appName = (TextView) findViewById(R.id.textView_appName);
        appVersion = (TextView) findViewById(R.id.textView_appVersion);
        androidVersion = (TextView) findViewById(R.id.textView_androidVersion);
        rfbLink = (TextView) findViewById(R.id.textView_rfbLink);

        final SpannableString content = new SpannableString(getString(R.string.sobre_rfb_link));
        content.setSpan(new UnderlineSpan(), 0, content.length(), 0);
        rfbLink.setText(content);
        rfbLink.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String url = "http://" + getString(R.string.sobre_rfb_link).replace("<u>", "").replace("</u>", "");
                openLink(url);
            }
        });
    }

    protected void preencherTela() {
        if (icon != 0) {
            appIcon.setImageResource(icon);
        }

        if (name != null) {
            appName.setText(name);
        }

        if (version != null) {
            appVersion.setText("v" + version);
        }

        if (versionSO != null) {
            androidVersion.setText("Android v" + versionSO);
        }
    }
}
