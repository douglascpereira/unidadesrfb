package br.gov.fazenda.receita.rfb.exception;

public class AmbienteIndisponivelException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public AmbienteIndisponivelException() {
		super();
	}

	public AmbienteIndisponivelException(String detailMessage, Throwable throwable) {
		super(detailMessage, throwable);
	}

	public AmbienteIndisponivelException(String detailMessage) {
		super(detailMessage);
	}

	public AmbienteIndisponivelException(Throwable throwable) {
		super(throwable);
	}

}
