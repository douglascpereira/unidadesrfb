package br.gov.fazenda.receita.rfb.model;

import java.io.Serializable;

public class RetornoPadrao implements Serializable {

    private static final long serialVersionUID = 1L;

    public String codigoRetorno;
    public String mensagemRetorno;
    public String dataConsulta;
    public String horaConsulta;
    public String exception;
    public String hash;
    public String timeout;
    public String conteudo;
}
